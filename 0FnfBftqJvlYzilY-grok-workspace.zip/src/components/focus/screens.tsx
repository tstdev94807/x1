import { useEffect, useLayoutEffect, useRef, useState } from "react";
import {
  Aperture,
  Ban,
  Bluetooth,
  BookOpen,
  CalendarDays,
  Check,
  Cloud,
  CloudRain,
  EyeOff,
  Gamepad2,
  Gauge,
  Globe,
  Laptop,
  LayoutGrid,
  Lock,
  MapPin,
  MessageSquare,
  Music,
  Phone,
  Plus,
  RotateCcw,
  Shield,
  Smartphone,
  StickyNote,
  Timer,
  Tv,
  TriangleAlert,
} from "lucide-react";
import { clockDrift, initClock, nudgeDemoClock, resetDemoClock, trustedWall } from "@/lib/focus/clock";
import { setSoundClip, soundClip, startSound, stopSound } from "@/lib/focus/audio";
import {
  BREAK_MIN,
  CATALOG,
  dayKeyFrom,
  FOCUS_MIN,
  formatMinutes,
  formatRemain,
  formatUsage,
  isAdultTarget,
  resolveLock,
  scheduleEnd,
  shiftDay,
  WALLPAPERS,
  WEEK,
  weekday,
  type DeviceId,
  type LimitId,
  type LockInfo,
  type TabId,
  type Task,
} from "@/lib/focus/model";
import { correctRemaining, restoreRemaining } from "@/lib/focus/model";
import { getServerNow } from "@/lib/focus/server-time";
import {
  loadPersisted,
  savePersisted,
  STORAGE_KEY,
  toPersisted,
  useFocus,
  type Persisted,
} from "@/lib/focus/store";

const IDLE_LOCK: LockInfo = { active: false, endsAt: null, reason: null, label: "", remainingMs: 0 };
const DURATIONS = [1, 15, 25, 45, 60, 120, 240, 480, 720];

const btn =
  "inline-flex h-11 items-center justify-center gap-2 rounded-xl px-4 text-sm font-medium transition-colors disabled:cursor-not-allowed disabled:opacity-40";
const primary = `${btn} bg-brass text-bg`;
const ghost = `${btn} border border-line bg-surface text-fg`;
const field =
  "h-11 w-full rounded-xl border border-line bg-bg px-3 text-sm text-fg outline-none focus-visible:border-brass";

const TABS: { id: TabId; label: string; icon: typeof Lock }[] = [
  { id: "today", label: "اليوم", icon: LayoutGrid },
  { id: "lock", label: "القفل", icon: Lock },
  { id: "limits", label: "الحدود", icon: Gauge },
  { id: "shield", label: "الدرع", icon: Shield },
  { id: "pomo", label: "بومودورو", icon: Timer },
  { id: "day", label: "الجدول", icon: CalendarDays },
];

function deviceName(device: DeviceId): string {
  return device === "phone" ? "الهاتف" : "الحاسوب";
}

function otherDevice(device: DeviceId): DeviceId {
  return device === "phone" ? "laptop" : "phone";
}

function usageText(ms: number): string {
  const { h, m } = formatUsage(ms);
  return `${h} س ${String(m).padStart(2, "0")} د`;
}

function clockFace(epoch: number): string {
  const date = new Date(epoch);
  return `${formatMinutes(date.getHours() * 60 + date.getMinutes())}:${String(date.getSeconds()).padStart(2, "0")}`;
}

function weekStart(key: string): string {
  return shiftDay(key, -((weekday(key) + 1) % 7));
}

function onThisDay(task: Task, selected: string, today: string | null): boolean {
  if (task.day === selected) return true;
  return task.day === "*" && (today == null || selected === today || selected === "*");
}

function UsageFigure({ ms, large }: { ms: number; large?: boolean }) {
  const { h, m } = formatUsage(ms);
  return (
    <p className={large ? "text-6xl font-light tabular-nums tracking-tight" : "text-3xl font-light tabular-nums"}>
      {h}
      <span className="text-base text-muted"> س </span>
      {String(m).padStart(2, "0")}
      <span className="text-base text-muted"> د</span>
    </p>
  );
}

export function Sakeena() {
  const state = useFocus();
  const [device, setDevice] = useState<DeviceId>("laptop");
  const [tab, setTab] = useState<TabId>("today");
  const [now, setNow] = useState<number | null>(null);
  const [foreground, setForeground] = useState<string | null>(null);
  const [playing, setPlaying] = useState<LimitId | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const playingRef = useRef<LimitId | null>(null);
  const deviceRef = useRef<DeviceId>("phone");
  const latched = useRef(false);
  playingRef.current = playing;
  deviceRef.current = device;

  useLayoutEffect(() => {
    initClock();
    const trusted = trustedWall();
    setNow(trusted);
    const snap = loadPersisted();
    if (!snap) {
      const today = dayKeyFrom(trusted);
      useFocus.getState().stampSeedDays(today);
      useFocus.getState().markReady({ usageDay: today });
    } else {
      const restored = restoreRemaining({
        remainingMs: snap.remainingMs ?? 0,
        savedAtWall: snap.savedAtWall ?? Date.now(),
        nowWall: Date.now(),
      });
      const manualEndsAt = restored.remainingMs > 1000 ? trusted + restored.remainingMs : null;
      useFocus.getState().applyPersisted(snap, manualEndsAt);
      useFocus.getState().stampSeedDays(dayKeyFrom(trusted));
      if (restored.tamper) {
        useFocus.setState((current) => ({
          tamperStrikes: current.tamperStrikes + 1,
          tamperNote: "بعد الإقلاع كانت الساعة متأخرة. أُعيد الوقت المتبقي وأُضيفت 15 دقيقة.",
        }));
      }
      void verifyNetworkTime(snap, manualEndsAt);
    }

    let last = trustedWall();
    let bucket = 0;
    const timer = window.setInterval(() => {
      const tick = trustedWall();
      const delta = Math.min(5000, Math.max(0, tick - last));
      last = tick;
      setNow(tick);
      const drift = clockDrift();
      if (Math.abs(drift) > 8000) {
        if (!latched.current) {
          latched.current = true;
          const note =
            drift > 0
              ? "رُصد تقديم ساعة الجهاز. القفل بقي على الساعة الداخلية وأُضيفت 15 دقيقة."
              : "رُصد تأخير ساعة الجهاز. أُضيفت 15 دقيقة ولم يُقبل الوقت الجديد.";
          useFocus.getState().punishClock(tick, note);
        }
      } else {
        latched.current = false;
      }
      bucket += delta;
      if (bucket >= 1000) {
        const chunk = bucket;
        bucket = 0;
        useFocus.getState().onTick(chunk, tick, playingRef.current, deviceRef.current, document.visibilityState === "visible");
      } else {
        useFocus.getState().onTick(0, tick, null, deviceRef.current, false);
      }
    }, 500);

    let persistTimer = 0;
    const unsub = useFocus.subscribe((next) => {
      if (!next.ready) return;
      window.clearTimeout(persistTimer);
      persistTimer = window.setTimeout(() => {
        savePersisted(toPersisted(next, trustedWall(), Date.now()));
      }, 400);
    });
    const flush = () => {
      const current = useFocus.getState();
      if (!current.ready) return;
      savePersisted(toPersisted(current, trustedWall(), Date.now()));
    };
    const onStorage = (event: StorageEvent) => {
      if (event.key !== STORAGE_KEY || !event.newValue) return;
      try {
        const incoming = JSON.parse(event.newValue) as Persisted;
        if (!incoming || incoming.rev <= useFocus.getState().rev) return;
        const trustedNow = trustedWall();
        const restored = restoreRemaining({
          remainingMs: incoming.remainingMs ?? 0,
          savedAtWall: incoming.savedAtWall ?? Date.now(),
          nowWall: Date.now(),
        });
        useFocus.getState().applyPersisted(incoming, restored.remainingMs > 500 ? trustedNow + restored.remainingMs : null);
      } catch {
        /* ignore malformed peer payloads */
      }
    };
    window.addEventListener("storage", onStorage);
    window.addEventListener("pagehide", flush);
    return () => {
      window.clearInterval(timer);
      window.clearTimeout(persistTimer);
      unsub();
      window.removeEventListener("storage", onStorage);
      window.removeEventListener("pagehide", flush);
      stopSound();
    };
  }, []);

  const lock = now == null ? IDLE_LOCK : resolveLock(state.manualEndsAt, state.schedules, now);
  const allowedFront = foreground != null && state.allowed.some((app) => app.id === foreground);
  const showApp = foreground != null && (!lock.active || allowedFront);

  useEffect(() => {
    if (lock.active && foreground && !allowedFront) {
      setForeground(null);
      setPlaying(null);
      setNotice("أُغلق التطبيق لأنه ليس ضمن المسموح. القفل عاد إلى الأمام.");
    }
  }, [lock.active, foreground, allowedFront]);

  useEffect(() => {
    if (!lock.active) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") event.preventDefault();
    };
    const onLeave = (event: BeforeUnloadEvent) => {
      event.preventDefault();
      event.returnValue = "";
    };
    window.addEventListener("keydown", onKey);
    window.addEventListener("beforeunload", onLeave);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("beforeunload", onLeave);
    };
  }, [lock.active]);

  useEffect(() => {
    if (state.pomo.phase === "idle") stopSound();
  }, [state.pomo.phase]);

  const strikes = state.tamperStrikes;
  const strikeBoot = useRef(true);
  useEffect(() => {
    if (strikeBoot.current) {
      strikeBoot.current = false;
      return;
    }
    if (state.tamperNote) setNotice(state.tamperNote);
  }, [strikes, state.tamperNote]);

  useEffect(() => {
    if (!playing) return;
    const rule = state.limits.find((item) => item.id === playing);
    if (rule && rule.usedMs >= rule.minutesPerHour * 60_000) {
      setPlaying(null);
      setNotice("نفد حد المقاطع القصيرة لهذه الساعة. يبقى استخدام التطبيق بدونها.");
    }
  }, [playing, state.limits]);

  useEffect(() => {
    if (!notice) return;
    const id = window.setTimeout(() => setNotice(null), 4200);
    return () => window.clearTimeout(id);
  }, [notice]);

  function openApp(id: string) {
    const trusted = trustedWall();
    const current = resolveLock(useFocus.getState().manualEndsAt, useFocus.getState().schedules, trusted);
    const allowed = useFocus.getState().allowed.some((app) => app.id === id);
    if (current.active && !allowed) {
      setForeground(null);
      setNotice("هذا التطبيق خارج قائمة المسموح. القفل يبقى فوقه.");
      return;
    }
    setForeground(id);
  }

  function playChosen() {
    const sound = useFocus.getState().pomo.sound;
    if (sound === "rain") {
      void startSound("rain");
      return;
    }
    if ((sound === "quran" || sound === "custom") && soundClip()) {
      void startSound("file").catch(() => setNotice("تعذّر تشغيل الملف. اختره مرة أخرى."));
      return;
    }
    if (sound === "quran") setNotice("اختر ملف تلاوة من جهازك. المؤقت يعمل والصوت ينتظر الملف.");
    if (sound === "custom") setNotice("اختر ملف الصوت الخاص. المؤقت يعمل بدونه حتى تضيفه.");
  }

  const twin = otherDevice(device);
  const total = state.usage.phone + state.usage.laptop;

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <div inert={lock.active || showApp ? true : undefined}>
        <header className="sticky top-0 z-30 border-b border-line bg-bg">
          <div className="mx-auto flex w-full max-w-6xl items-center justify-between gap-3 px-4 py-3">
            <div className="flex items-center gap-3">
              <span className="grid size-10 place-items-center rounded-xl bg-surface-2" aria-hidden>
                <span className="h-4 w-px bg-brass" />
              </span>
              <div>
                <p className="text-lg font-medium leading-none">سكينة</p>
                <p className="mt-1 text-xs text-muted">قفل واحد للجهازين</p>
              </div>
            </div>
            <div className="flex rounded-xl border border-line p-1">
              {(["phone", "laptop"] as DeviceId[]).map((id) => (
                <button
                  key={id}
                  type="button"
                  className={`inline-flex h-10 items-center gap-2 rounded-lg px-3 text-sm ${device === id ? "bg-brass text-bg" : "text-muted"}`}
                  onClick={() => setDevice(id)}
                >
                  {id === "phone" ? <Smartphone className="size-4" /> : <Laptop className="size-4" />}
                <span>{id === "phone" ? "هاتف" : "حاسوب"}</span>
                </button>
              ))}
            </div>
          </div>
          <div className="mx-auto flex w-full max-w-6xl items-center justify-between gap-3 border-t border-line px-4 py-2 text-sm">
            <p className="min-w-0 truncate text-muted">
              {deviceName(twin)} · {usageText(state.usage[twin])} · {lock.active ? "مقفل مع هذا الجهاز" : "مفتوح"}
            </p>
            <p className="inline-flex shrink-0 items-center gap-2 text-sage">
              {state.transport === "internet" ? <Cloud className="size-4" /> : <Bluetooth className="size-4" />}
              متزامن
            </p>
          </div>
          <nav className="tabs mx-auto flex w-full max-w-6xl gap-2 overflow-x-auto px-4 pb-3" aria-label="أقسام سكينة">
            {TABS.map((item) => {
              const Icon = item.icon;
              const on = tab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  className={`inline-flex h-11 shrink-0 items-center gap-2 rounded-full px-4 text-sm ${on ? "bg-brass text-bg" : "bg-surface text-muted"}`}
                  onClick={() => setTab(item.id)}
                >
                  <Icon className="size-4" />
                  {item.label}
                </button>
              );
            })}
          </nav>
        </header>

        <div className="mx-auto grid w-full max-w-6xl items-start lg:grid-cols-[minmax(0,1fr)_18rem]">
          <main className={device === "phone" ? "mx-auto w-full max-w-md px-4 py-5" : "min-w-0 px-4 py-5"}>
            {tab === "today" ? (
              <Today
                total={total}
                now={now}
                onOpen={openApp}
                onTab={setTab}
                device={device}
              />
            ) : null}
            {tab === "lock" ? <LockSettings now={now} notice={setNotice} /> : null}
            {tab === "limits" ? <Limits now={now} onOpen={openApp} /> : null}
            {tab === "shield" ? <ShieldView now={now} notice={setNotice} /> : null}
            {tab === "pomo" ? <PomoView now={now} notice={setNotice} onPlay={playChosen} /> : null}
            {tab === "day" ? <Agenda now={now} /> : null}
          </main>
          <TwinCard device={twin} now={now} lock={lock} onSwitch={() => setDevice(twin)} />
        </div>
      </div>

      {lock.active && !showApp && now != null ? (
        <LockScreen
          device={device}
          lock={lock}
          now={now}
          onOpen={openApp}
          onSwitch={() => setDevice(twin)}
          onPlay={playChosen}
          notice={setNotice}
        />
      ) : null}
      {showApp && foreground ? (
        <AppLayer
          id={foreground}
          locked={lock.active}
          remaining={lock.remainingMs}
          now={now}
          playing={playing}
          onPlay={setPlaying}
          onClose={() => {
            setForeground(null);
            setPlaying(null);
          }}
          notice={setNotice}
        />
      ) : null}
      {notice ? (
        <div className="fixed inset-x-4 top-4 z-50 mx-auto max-w-md rounded-2xl border border-line bg-surface px-4 py-3 text-sm" role="status">
          {notice}
        </div>
      ) : null}
    </div>
  );
}

async function verifyNetworkTime(snap: Persisted, expectedEnd: number | null): Promise<void> {
  if ((snap.remainingMs ?? 0) <= 0) return;
  try {
    const t0 = Date.now();
    const result = await getServerNow();
    const t1 = Date.now();
    const skew = t0 + (t1 - t0) / 2 - result.now;
    const currentEnd = useFocus.getState().manualEndsAt;
    if (currentEnd !== expectedEnd) return;
    useFocus.setState({ savedSkew: skew });
    const corrected = correctRemaining({
      remainingMs: snap.remainingMs,
      savedAtWall: snap.savedAtWall,
      savedSkew: snap.savedSkew ?? 0,
      nowWall: Date.now(),
      skew,
    });
    if (useFocus.getState().manualEndsAt !== expectedEnd) return;
    const trusted = trustedWall();
    if (corrected.cheated) {
      useFocus.getState().commit({
        manualEndsAt: trusted + corrected.remainingMs,
        tamperStrikes: useFocus.getState().tamperStrikes + 1,
        tamperNote: "وقت الشبكة لا يطابق ساعة الجهاز. استُكمل القفل وأُضيفت 15 دقيقة.",
        lastSync: "نُسخ إنذار الساعة إلى الجهاز الآخر",
      });
      return;
    }
    useFocus.setState({
      manualEndsAt: corrected.remainingMs > 1000 ? trusted + corrected.remainingMs : null,
    });
  } catch {
    const current = useFocus.getState().tamperNote;
    if (!current) {
      useFocus.setState({ tamperNote: "تعذّر التحقق من وقت الشبكة هذه المرة. القفل المحلي ما زال سارياً." });
    }
  }
}

function TwinCard({
  device,
  now,
  lock,
  onSwitch,
}: {
  device: DeviceId;
  now: number | null;
  lock: LockInfo;
  onSwitch: () => void;
}) {
  const wall = useFocus((s) => s.wallpapers[device]);
  const usage = useFocus((s) => s.usage[device]);
  const name = WALLPAPERS.find((item) => item.id === wall)?.name ?? "";
  return (
    <aside className="sticky top-36 hidden px-4 py-5 lg:block">
      <div className={`wall wall-${wall} overflow-hidden rounded-3xl border border-line p-5`}>
        <p className="text-sm opacity-70">{deviceName(device)}</p>
        <p className="mt-6 text-4xl font-light tabular-nums">{lock.active && now != null ? formatRemain(lock.remainingMs) : usageText(usage)}</p>
        <p className="mt-2 text-sm opacity-70">{lock.active ? "نفس العدّاد على الجهازين" : `خلفية ${name}`}</p>
        <button type="button" className="mt-6 inline-flex h-11 w-full items-center justify-center rounded-xl bg-bg px-4 text-sm font-medium text-paper" onClick={onSwitch}>
          الانتقال إلى {deviceName(device)}
        </button>
      </div>
    </aside>
  );
}

function Today({
  total,
  now,
  onOpen,
  onTab,
  device,
}: {
  total: number;
  now: number | null;
  onOpen: (id: string) => void;
  onTab: (tab: TabId) => void;
  device: DeviceId;
}) {
  const usage = useFocus((s) => s.usage);
  const tasks = useFocus((s) => s.tasks);
  const toggleTask = useFocus((s) => s.toggleTask);
  const today = now == null ? null : dayKeyFrom(now);
  const openTasks = tasks.filter((task) => !task.done && onThisDay(task, today ?? "*", today));
  return (
    <div className="flex flex-col gap-5">
      <section>
        <p className="text-sm text-muted">ما مضى اليوم على الجهازين وأنت تتصفح {deviceName(device)}</p>
        <UsageFigure ms={total} large />
      </section>
      <div className="grid grid-cols-2 gap-3">
        <article className="rounded-2xl border border-line bg-surface p-4">
          <p className="inline-flex items-center gap-2 text-sm text-muted">
            <Smartphone className="size-4" /> الهاتف
          </p>
          <UsageFigure ms={usage.phone} />
        </article>
        <article className="rounded-2xl border border-line bg-surface p-4">
          <p className="inline-flex items-center gap-2 text-sm text-muted">
            <Laptop className="size-4" /> الحاسوب
          </p>
          <UsageFigure ms={usage.laptop} />
        </article>
      </div>
      <section className="rounded-2xl border border-line bg-surface p-4">
        <div className="mb-3 flex items-center justify-between gap-3">
          <h2 className="text-base font-medium">مهام اليوم</h2>
          <button type="button" className="text-sm text-brass" onClick={() => onTab("day")}>
            الجدول
          </button>
        </div>
        {openTasks.length === 0 ? <p className="text-sm text-muted">لا مهام مفتوحة. أضف واحدة من الجدول بالدقيقة.</p> : null}
        <ul className="flex flex-col gap-2">
          {openTasks.map((task) => (
            <li key={task.id} className="flex items-center gap-3">
              <button
                type="button"
                className="grid size-11 place-items-center rounded-xl border border-line"
                aria-label={`إتمام ${task.title}`}
                onClick={() => toggleTask(task.id)}
              >
                <span className="size-3 rounded-sm border border-muted" />
              </button>
              <div>
                <p>{task.title}</p>
                <p className="text-sm tabular-nums text-muted">{formatMinutes(task.minutes)}</p>
              </div>
            </li>
          ))}
        </ul>
      </section>
      <section>
        <h2 className="mb-3 text-base font-medium">على الجهاز</h2>
        <div className="grid grid-cols-3 gap-2">
          {CATALOG.map((app) => (
            <button key={app.id} type="button" className={`${ghost} h-auto flex-col gap-2 py-3`} onClick={() => onOpen(app.id)}>
              <AppIcon id={app.id} />
              <span className="text-xs">{app.name}</span>
            </button>
          ))}
        </div>
      </section>
    </div>
  );
}

function AppIcon({ id }: { id: string }) {
  const cls = "size-5";
  if (id === "youtube") return <Tv className={cls} />;
  if (id === "instagram") return <Aperture className={cls} />;
  if (id === "tiktok") return <Music className={cls} />;
  if (id === "browser") return <Globe className={cls} />;
  if (id === "games") return <Gamepad2 className={cls} />;
  if (id === "call") return <Phone className={cls} />;
  if (id === "sms") return <MessageSquare className={cls} />;
  if (id === "maps") return <MapPin className={cls} />;
  return <StickyNote className={cls} />;
}

function LockSettings({ now, notice }: { now: number | null; notice: (text: string) => void }) {
  const schedules = useFocus((s) => s.schedules);
  const allowed = useFocus((s) => s.allowed);
  const transport = useFocus((s) => s.transport);
  const pairCode = useFocus((s) => s.pairCode);
  const wallpapers = useFocus((s) => s.wallpapers);
  const lastSync = useFocus((s) => s.lastSync);
  const commit = useFocus((s) => s.commit);
  const startManual = useFocus((s) => s.startManual);
  const addSchedule = useFocus((s) => s.addSchedule);
  const toggleSchedule = useFocus((s) => s.toggleSchedule);
  const removeSchedule = useFocus((s) => s.removeSchedule);
  const toggleAllowed = useFocus((s) => s.toggleAllowed);
  const addCustomAllowed = useFocus((s) => s.addCustomAllowed);
  const [minutes, setMinutes] = useState(25);
  const [label, setLabel] = useState("جلسة تركيز");
  const [start, setStart] = useState("17:00");
  const [end, setEnd] = useState("19:00");
  const [days, setDays] = useState<number[]>([0, 1, 2, 3, 4]);
  const [armAdd, setArmAdd] = useState(false);
  const [armToggle, setArmToggle] = useState<string | null>(null);
  const [customApp, setCustomApp] = useState("");

  function beginManual() {
    if (now == null) return;
    startManual(minutes, now);
    notice("الجهازان مقفلان الآن بنفس العدّاد.");
  }

  function beginSchedule() {
    if (days.length === 0) {
      notice("اختر يوماً واحداً على الأقل.");
      return;
    }
    const draft = { label, days, start, end, enabled: true };
    if (now != null && scheduleEnd({ ...draft, id: "tmp" }, now) && !armAdd) {
      setArmAdd(true);
      notice("هذا الموعد سيغلق الجهازين الآن. اضغط إضافة مرة أخرى للتأكيد.");
      return;
    }
    addSchedule(draft);
    setArmAdd(false);
    notice("نُسخ الموعد إلى الجهاز الآخر.");
  }

  return (
    <div className="flex flex-col gap-5">
      <section className="rounded-2xl border border-line bg-surface p-4">
        <h2 className="text-base font-medium">قفل يدوي</h2>
        <p className="mt-1 text-sm text-muted">من دقيقة إلى 12 ساعة. يبدأ على الهاتف والحاسوب معاً ولا يُلغى قبل وقته.</p>
        <div className="mt-4 grid grid-cols-3 gap-2 sm:grid-cols-5">
          {DURATIONS.map((value) => (
            <button
              key={value}
              type="button"
              className={`h-11 rounded-xl text-sm tabular-nums ${minutes === value ? "bg-brass text-bg" : "bg-bg text-fg"}`}
              onClick={() => setMinutes(value)}
            >
              {value < 60 ? `${value} د` : `${value / 60} س`}
            </button>
          ))}
        </div>
        <label className="mt-4 block text-sm text-muted" htmlFor="custom-minutes">
          مدة مخصصة بالدقائق
        </label>
        <input
          id="custom-minutes"
          className={`${field} mt-2`}
          inputMode="numeric"
          value={minutes}
          onChange={(event) => setMinutes(Math.min(720, Math.max(1, Number(event.target.value) || 1)))}
        />
        <button type="button" className={`${primary} mt-4 w-full`} disabled={now == null} onClick={beginManual}>
          <Lock className="size-4" />
          اقفل الجهازين {minutes < 60 ? `${minutes} د` : `${minutes / 60} س`}
        </button>
      </section>

      <section className="rounded-2xl border border-line bg-surface p-4">
        <h2 className="text-base font-medium">جدول القفل</h2>
        <p className="mt-1 text-sm text-muted">مثال: من الخامسة إلى السابعة. التفعيل ينسخ نفسه إلى الجهاز الآخر.</p>
        <ul className="mt-3 flex flex-col gap-2">
          {schedules.map((item) => (
            <li key={item.id} className="rounded-xl border border-line bg-bg p-3">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="font-medium">{item.label}</p>
                  <p className="text-sm tabular-nums text-muted">
                    {item.start} – {item.end} · {item.days.map((day) => WEEK.find((w) => w.d === day)?.label).join(" ")}
                  </p>
                </div>
                <button type="button" className="text-sm text-muted" onClick={() => removeSchedule(item.id)}>
                  حذف
                </button>
              </div>
              <button
                type="button"
                className={`mt-3 h-11 rounded-xl px-4 text-sm ${item.enabled ? "bg-sage text-bg" : "bg-surface-2 text-fg"}`}
                onClick={() => {
                  if (!item.enabled && now != null && scheduleEnd({ ...item, enabled: true }, now) && armToggle !== item.id) {
                    setArmToggle(item.id);
                    notice("التفعيل سيغلق الجهازين الآن. اضغط مرة أخرى للتأكيد.");
                    return;
                  }
                  toggleSchedule(item.id);
                  setArmToggle(null);
                }}
              >
                {item.enabled ? "مفعّل على الجهازين" : "غير مفعّل"}
              </button>
            </li>
          ))}
        </ul>
        <div className="mt-4 flex flex-col gap-3">
          <label className="text-sm text-muted" htmlFor="sch-label">
            اسم الموعد
          </label>
          <input id="sch-label" className={field} value={label} onChange={(event) => setLabel(event.target.value)} />
          <div className="grid grid-cols-2 gap-2">
            <label className="text-sm text-muted">
              من
              <input className={`${field} mt-1`} type="time" value={start} onChange={(event) => setStart(event.target.value)} />
            </label>
            <label className="text-sm text-muted">
              إلى
              <input className={`${field} mt-1`} type="time" value={end} onChange={(event) => setEnd(event.target.value)} />
            </label>
          </div>
          <div className="flex flex-wrap gap-2">
            {WEEK.map((day) => {
              const on = days.includes(day.d);
              return (
                <button
                  key={day.d}
                  type="button"
                  className={`h-11 rounded-xl px-3 text-sm ${on ? "bg-brass text-bg" : "bg-bg text-muted"}`}
                  onClick={() => setDays((current) => (current.includes(day.d) ? current.filter((d) => d !== day.d) : [...current, day.d]))}
                >
                  {day.label}
                </button>
              );
            })}
          </div>
          <button type="button" className={primary} onClick={beginSchedule}>
            <Plus className="size-4" />
            إضافة الموعد
          </button>
        </div>
      </section>

      <section className="rounded-2xl border border-line bg-surface p-4">
        <h2 className="text-base font-medium">تعمل أثناء القفل</h2>
        <p className="mt-1 text-sm text-muted">ما عدا هذه القائمة يُغطى بالقفل إذا فُتح بأي طريقة.</p>
        <div className="mt-3 flex flex-col gap-2">
          {CATALOG.map((app) => {
            const on = allowed.some((item) => item.id === app.id);
            return (
              <button
                key={app.id}
                type="button"
                className="flex h-12 items-center justify-between rounded-xl bg-bg px-3 text-sm"
                onClick={() => toggleAllowed(app.id, app.name)}
              >
                <span className="inline-flex items-center gap-2">
                  <AppIcon id={app.id} />
                  {app.name}
                </span>
                <span className={on ? "text-sage" : "text-muted"}>{on ? "مسموح" : "يُقفل"}</span>
              </button>
            );
          })}
          {allowed
            .filter((app) => !CATALOG.some((item) => item.id === app.id))
            .map((app) => (
              <button
                key={app.id}
                type="button"
                className="flex h-12 items-center justify-between rounded-xl bg-bg px-3 text-sm"
                onClick={() => toggleAllowed(app.id, app.name)}
              >
                {app.name}
                <span className="text-sage">مسموح</span>
              </button>
            ))}
        </div>
        <div className="mt-3 flex gap-2">
          <input
            className={field}
            placeholder="اسم تطبيق آخر"
            value={customApp}
            onChange={(event) => setCustomApp(event.target.value)}
            aria-label="تطبيق مسموح إضافي"
          />
          <button
            type="button"
            className={ghost}
            onClick={() => {
              addCustomAllowed(customApp);
              setCustomApp("");
            }}
          >
            إضافة
          </button>
        </div>
      </section>

      <section className="rounded-2xl border border-line bg-surface p-4">
        <h2 className="text-base font-medium">خلفية القفل</h2>
        <p className="mt-1 text-sm text-muted">لكل جهاز خلفية مستقلة، والعدّاد واحد.</p>
        {(["phone", "laptop"] as DeviceId[]).map((id) => (
          <div key={id} className="mt-4">
            <p className="mb-2 text-sm">{deviceName(id)}</p>
            <div className="grid grid-cols-4 gap-2">
              {WALLPAPERS.map((wall) => (
                <button
                  key={wall.id}
                  type="button"
                  className={`wall wall-${wall.id} h-16 rounded-xl border text-xs ${wallpapers[id] === wall.id ? "border-brass" : "border-transparent"}`}
                  onClick={() =>
                    commit((current) => ({
                      wallpapers: { ...current.wallpapers, [id]: wall.id },
                      lastSync: current.transport === "bluetooth" ? "تحدّثت الخلفية · نُسخت عبر البلوتوث" : "تحدّثت الخلفية · نُسخت عبر الإنترنت",
                    }))
                  }
                >
                  {wall.name}
                </button>
              ))}
            </div>
          </div>
        ))}
      </section>

      <section className="rounded-2xl border border-line bg-surface p-4">
        <h2 className="text-base font-medium">نسخ الإعدادات</h2>
        <p className="mt-1 text-sm text-muted">
          في هذه المعاينة ترى النسختين معاً، فأي قفل أو حد أو مهمة يصل إلى الجهاز الآخر فوراً. على الجهازين الحقيقيين تُرسل نفس الحالة عبر القناة التي تختارها.
        </p>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <button type="button" className={transport === "internet" ? primary : ghost} onClick={() => commit({ transport: "internet", lastSync: "القناة: الإنترنت" })}>
            <Cloud className="size-4" /> إنترنت
          </button>
          <button type="button" className={transport === "bluetooth" ? primary : ghost} onClick={() => commit({ transport: "bluetooth", lastSync: "القناة: بلوتوث" })}>
            <Bluetooth className="size-4" /> بلوتوث
          </button>
        </div>
        <label className="mt-4 block text-sm text-muted" htmlFor="pair">
          رمز الربط
        </label>
        <input
          id="pair"
          className={`${field} mt-2 uppercase tracking-widest`}
          value={pairCode}
          maxLength={8}
          onChange={(event) => commit({ pairCode: event.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8) })}
        />
        <p className="mt-3 text-sm text-sage">{lastSync}</p>
      </section>
    </div>
  );
}

function Limits({ now, onOpen }: { now: number | null; onOpen: (id: string) => void }) {
  const limits = useFocus((s) => s.limits);
  const setLimitMinutes = useFocus((s) => s.setLimitMinutes);
  return (
    <div className="flex flex-col gap-4">
      <section>
        <h2 className="text-base font-medium">حد المقاطع القصيرة</h2>
        <p className="mt-1 text-sm text-muted">عشر دقائق كل ساعة افتراضياً. الويب والتطبيق يحسبان من الرصيد نفسه. بعد النفاد يبقى البرنامج بلا مقاطع قصيرة.</p>
      </section>
      {limits.map((rule) => {
        const cap = rule.minutesPerHour * 60_000;
        const pct = Math.min(100, Math.round((rule.usedMs / cap) * 100));
        const left = Math.max(0, cap - rule.usedMs);
        const reset = now == null ? null : Math.ceil((Math.floor(now / 3_600_000 + 1) * 3_600_000 - now) / 1000);
        return (
          <article key={rule.id} className="rounded-2xl border border-line bg-surface p-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="font-medium">{rule.name}</h3>
                <p className="text-sm text-muted">{rule.detail}</p>
              </div>
              <p className="tabular-nums text-sm text-brass">{formatRemain(left)}</p>
            </div>
            <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-bg">
              <div className="h-full bg-brass" style={{ width: `${pct}%` }} />
            </div>
            <p className="mt-2 text-sm text-muted">
              {Math.ceil(rule.usedMs / 60000)} / {rule.minutesPerHour} د هذه الساعة
              {reset != null ? ` · تتجدد بعد ${formatRemain(reset * 1000)}` : ""}
            </p>
            <label className="mt-3 block text-sm text-muted" htmlFor={`lim-${rule.id}`}>
              الدقائق المسموحة كل ساعة
            </label>
            <input
              id={`lim-${rule.id}`}
              className={`${field} mt-1`}
              inputMode="numeric"
              value={rule.minutesPerHour}
              onChange={(event) => setLimitMinutes(rule.id, Number(event.target.value) || 1)}
            />
          </article>
        );
      })}
      <button type="button" className={primary} onClick={() => onOpen("youtube")}>
        تجربة يوتيوب
      </button>
    </div>
  );
}

function ShieldView({ now, notice }: { now: number | null; notice: (text: string) => void }) {
  const strikes = useFocus((s) => s.tamperStrikes);
  const tamperNote = useFocus((s) => s.tamperNote);
  const [url, setUrl] = useState("");
  const [verdict, setVerdict] = useState<string | null>(null);
  const drift = now == null ? 0 : clockDrift();

  return (
    <div className="flex flex-col gap-4">
      <section className="rounded-2xl border border-line bg-surface p-4">
        <div className="flex items-center gap-2">
          <Ban className="size-5 text-brass" />
          <h2 className="text-base font-medium">حجب دائم</h2>
        </div>
        <p className="mt-2 text-sm text-muted">
          أي موقع إباحي أو هنتاي يُحجب في كل الأوقات على الهاتف والحاسوب، من المتصفح ومن التطبيقات. لا يوجد مفتاح إيقاف.
        </p>
        <label className="mt-3 block text-sm text-muted" htmlFor="adult-url">
          جرّب عنواناً
        </label>
        <div className="mt-2 flex gap-2">
          <input
            id="adult-url"
            className={field}
            value={url}
            placeholder="example.com"
            onChange={(event) => setUrl(event.target.value)}
          />
          <button
            type="button"
            className={ghost}
            onClick={() => setVerdict(isAdultTarget(url) ? "محجوب نهائياً" : "ليس ضمن الحجب الدائم")}
          >
            فحص
          </button>
        </div>
        {verdict ? <p className="mt-3 text-sm text-brass">{verdict}</p> : null}
      </section>

      <section className="rounded-2xl border border-line bg-surface p-4">
        <div className="flex items-center gap-2">
          <EyeOff className="size-5 text-brass" />
          <h2 className="text-base font-medium">التصفح الخفي متوقف</h2>
        </div>
        <p className="mt-2 text-sm text-muted">الزر موجود في مكانه حتى لا يُظن أنه اختفى، لكنه لا يفتح نافذة خاصة على أي جهاز.</p>
        <div className="mt-3">
          <IncognitoControl
            onBlock={() => notice("التصفح الخفي متوقف على الهاتف والحاسوب ولا يمكن فتحه.")}
          />
        </div>
      </section>

      <section className="rounded-2xl border border-line bg-surface p-4">
        <div className="flex items-center gap-2">
          <TriangleAlert className="size-5 text-brass" />
          <h2 className="text-base font-medium">ساعة لا تُخدع</h2>
        </div>
        <p className="mt-2 text-sm text-muted">
          أثناء القفل يعتمد العدّاد ساعة داخلية. تقديم ساعة الجهاز أو تأخيرها لا ينهي القفل، ويُضاف خمس عشرة دقيقة. بعد إعادة التشغيل يُراجع الوقت مع الشبكة.
        </p>
        <dl className="mt-3 grid grid-cols-2 gap-3 text-sm">
          <div className="rounded-xl bg-bg p-3">
            <dt className="text-muted">ساعة سكينة</dt>
            <dd className="mt-1 tabular-nums">{now == null ? "—" : clockFace(now)}</dd>
          </div>
          <div className="rounded-xl bg-bg p-3">
            <dt className="text-muted">ساعة الجهاز</dt>
            <dd className="mt-1 tabular-nums">{now == null ? "—" : clockFace(Date.now() + drift)}</dd>
          </div>
        </dl>
        <p className="mt-3 text-sm">محاولات مكتشفة: {strikes}</p>
        {tamperNote ? <p className="mt-2 text-sm text-brass">{tamperNote}</p> : null}
        <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
          <button type="button" className={ghost} onClick={() => nudgeDemoClock(30 * 60 * 1000)}>
            محاكاة تقديم الساعة
          </button>
          <button type="button" className={ghost} onClick={() => nudgeDemoClock(-10 * 60 * 1000)}>
            محاكاة تأخير الساعة
          </button>
          <button
            type="button"
            className={ghost}
            onClick={() => {
              resetDemoClock();
              notice("عادت ساعة الجهاز الظاهرة إلى وضعها.");
            }}
          >
            إرجاع الساعة الظاهرة
          </button>
          <button
            type="button"
            className={ghost}
            onClick={() => {
              const current = useFocus.getState();
              if (current.ready) savePersisted(toPersisted(current, trustedWall(), Date.now()));
              window.location.reload();
            }}
          >
            <RotateCcw className="size-4" />
            محاكاة إعادة التشغيل
          </button>
        </div>
      </section>
      <p className="text-sm text-muted">
        القفل هنا يغطي المعاينة بالكامل ويبقى بعد التحديث. النسخة المثبتة على ويندوز وأندرويد هي التي تجلس فوق النظام وتعطّل التصفح الخفي من إعدادات الجهاز.
      </p>
    </div>
  );
}

function IncognitoControl({ onBlock }: { onBlock: () => void }) {
  return (
    <button
      type="button"
      aria-disabled="true"
      className={`${ghost} w-full opacity-60`}
      onClick={onBlock}
    >
      <EyeOff className="size-4" />
      نافذة خاصة · متوقفة
    </button>
  );
}

function PomoView({
  now,
  notice,
  onPlay,
}: {
  now: number | null;
  notice: (text: string) => void;
  onPlay: () => void;
}) {
  const pomo = useFocus((s) => s.pomo);
  const startPomo = useFocus((s) => s.startPomo);
  const stopPomo = useFocus((s) => s.stopPomo);
  const setPomoCycles = useFocus((s) => s.setPomoCycles);
  const setSound = useFocus((s) => s.setSound);
  const totalMs = (pomo.phase === "break" ? BREAK_MIN : FOCUS_MIN) * 60_000;
  const left = pomo.phaseEndsAt != null && now != null ? Math.max(0, pomo.phaseEndsAt - now) : totalMs;
  const progress = totalMs === 0 ? 0 : left / totalMs;
  const radius = 52;
  const circ = 2 * Math.PI * radius;
  const phaseLabel = pomo.phase === "focus" ? "تركيز" : pomo.phase === "break" ? "استراحة" : "جاهز";

  function chooseFile(kind: "quran" | "custom", file: File | null) {
    if (!file) return;
    setSoundClip(URL.createObjectURL(file));
    setSound(kind, file.name);
    notice(kind === "quran" ? "أُضيف ملف التلاوة على هذا الجهاز." : "أُضيف الصوت الخاص على هذا الجهاز.");
    if (useFocus.getState().pomo.phase !== "idle") onPlay();
  }

  return (
    <div className="flex flex-col items-center gap-5">
      <div className="relative grid place-items-center">
        <svg viewBox="0 0 120 120" className="size-56 text-brass" aria-hidden>
          <circle cx="60" cy="60" r={radius} fill="none" stroke="currentColor" strokeOpacity={0.2} strokeWidth="6" />
          <circle
            cx="60"
            cy="60"
            r={radius}
            fill="none"
            stroke="currentColor"
            strokeWidth="6"
            strokeLinecap="round"
            strokeDasharray={circ}
            strokeDashoffset={circ * (1 - progress)}
            transform="rotate(-90 60 60)"
          />
        </svg>
        <div className="absolute text-center">
          <p className="text-4xl font-light tabular-nums">{formatRemain(left)}</p>
          <p className="text-sm text-muted">{phaseLabel}</p>
        </div>
      </div>
      <p className="text-sm text-muted">
        25 دقيقة تركيز ثم 5 استراحة · الدورة {Math.min(pomo.cyclesDone + (pomo.phase === "idle" ? 0 : 1), pomo.cyclesPlanned)} من {pomo.cyclesPlanned}
      </p>
      <div className="flex items-center gap-3">
        <button type="button" className={ghost} disabled={pomo.phase !== "idle"} onClick={() => setPomoCycles(pomo.cyclesPlanned - 1)}>
          أقل
        </button>
        <span className="tabular-nums">{pomo.cyclesPlanned} دورات</span>
        <button type="button" className={ghost} disabled={pomo.phase !== "idle"} onClick={() => setPomoCycles(pomo.cyclesPlanned + 1)}>
          أكثر
        </button>
      </div>
      <div className="grid w-full grid-cols-3 gap-2">
        <button type="button" className={pomo.sound === "rain" ? primary : ghost} onClick={() => { setSound("rain"); if (pomo.phase !== "idle") onPlay(); }}>
          <CloudRain className="size-4" /> مطر
        </button>
        <label className={pomo.sound === "quran" ? primary : ghost}>
          <BookOpen className="size-4" /> تلاوة
          <input
            className="sr-only"
            type="file"
            accept="audio/*"
            onChange={(event) => chooseFile("quran", event.target.files?.[0] ?? null)}
          />
        </label>
        <label className={pomo.sound === "custom" ? primary : ghost}>
          <Music className="size-4" /> خاص
          <input
            className="sr-only"
            type="file"
            accept="audio/*"
            onChange={(event) => chooseFile("custom", event.target.files?.[0] ?? null)}
          />
        </label>
      </div>
      <p className="text-center text-sm text-muted">
        {pomo.sound === "quran"
          ? pomo.customSoundName || "التلاوة ملف من جهازك، ولا تُولَّد تلاوة مصطنعة."
          : pomo.sound === "custom"
            ? pomo.customSoundName || "أضف ملف صوت من جهازك."
            : "صوت مطر خفيف أثناء الدورات."}
      </p>
      {pomo.phase === "idle" ? (
        <button
          type="button"
          className={`${primary} w-full`}
          disabled={now == null}
          onClick={() => {
            if (now == null) return;
            startPomo(now);
            onPlay();
          }}
        >
          ابدأ {pomo.cyclesPlanned} دورات
        </button>
      ) : (
        <button type="button" className={`${ghost} w-full`} onClick={() => stopPomo()}>
          إيقاف السلسلة
        </button>
      )}
    </div>
  );
}

function Agenda({ now }: { now: number | null }) {
  const tasks = useFocus((s) => s.tasks);
  const addTask = useFocus((s) => s.addTask);
  const toggleTask = useFocus((s) => s.toggleTask);
  const removeTask = useFocus((s) => s.removeTask);
  const today = now == null ? null : dayKeyFrom(now);
  const [picked, setPicked] = useState<string | null>(null);
  const [title, setTitle] = useState("");
  const [time, setTime] = useState("17:00");
  const selected = picked ?? today ?? "*";
  const start = today ? weekStart(picked ?? today) : null;
  const visible = tasks
    .filter((task) => onThisDay(task, selected, today))
    .slice()
    .sort((a, b) => a.minutes - b.minutes);
  const hours = Array.from({ length: 24 }, (_, hour) => hour);

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between gap-2">
        <button type="button" className={ghost} disabled={!today} onClick={() => setPicked(shiftDay(selected === "*" && today ? today : selected, -1))}>
          السابق
        </button>
        <h2 className="text-center text-base font-medium">{selected === "*" || !today ? "اليوم" : dayTitle(selected)}</h2>
        <button type="button" className={ghost} disabled={!today} onClick={() => setPicked(shiftDay(selected === "*" && today ? today : selected, 1))}>
          التالي
        </button>
      </div>
      <div className="grid grid-cols-7 gap-1">
        {WEEK.map((day, index) => {
          const key = start ? shiftDay(start, index) : "";
          const on = key !== "" && key === (selected === "*" ? today : selected);
          return (
            <button
              key={day.d}
              type="button"
              disabled={!start}
              className={`flex h-14 flex-col items-center justify-center rounded-xl text-xs ${on ? "bg-brass text-bg" : "bg-surface text-muted"}`}
              onClick={() => key && setPicked(key)}
            >
              <span>{day.label}</span>
              <span className="tabular-nums">{key ? key.slice(-2) : ""}</span>
            </button>
          );
        })}
      </div>
      <form
        className="flex flex-col gap-2 rounded-2xl border border-line bg-surface p-4"
        onSubmit={(event) => {
          event.preventDefault();
          if (!title.trim() || !today) return;
          const [h, m] = time.split(":").map(Number);
          addTask({
            title: title.trim(),
            day: selected === "*" ? today : selected,
            minutes: (h ?? 0) * 60 + (m ?? 0),
          });
          setTitle("");
        }}
      >
        <label className="text-sm text-muted" htmlFor="task-title">
          مهمة بالدقيقة
        </label>
        <input id="task-title" className={field} value={title} onChange={(event) => setTitle(event.target.value)} placeholder="ماذا ستفعل" />
        <input className={field} type="time" value={time} onChange={(event) => setTime(event.target.value)} aria-label="وقت المهمة" />
        <button type="submit" className={primary} disabled={!today || !title.trim()}>
          إضافة إلى الجدول
        </button>
      </form>
      <div className="max-h-[32rem] overflow-y-auto rounded-2xl border border-line">
        {hours.map((hour) => {
          const rows = visible.filter((task) => Math.floor(task.minutes / 60) === hour);
          return (
            <div key={hour} className="grid grid-cols-[4.5rem_minmax(0,1fr)] border-b border-line last:border-b-0">
              <button type="button" className="px-3 py-3 text-start text-sm tabular-nums text-muted" onClick={() => setTime(`${String(hour).padStart(2, "0")}:00`)}>
                {formatMinutes(hour * 60)}
              </button>
              <div className="flex flex-col gap-2 py-2 pe-3">
                {rows.length === 0 ? <span className="py-2 text-sm text-muted">—</span> : null}
                {rows.map((task) => (
                  <div key={task.id} className="flex items-center gap-2">
                    <button
                      type="button"
                      className={`grid size-11 place-items-center rounded-xl border ${task.done ? "border-sage bg-sage text-bg" : "border-line"}`}
                      aria-label={task.done ? `إلغاء إتمام ${task.title}` : `إتمام ${task.title}`}
                      onClick={() => toggleTask(task.id)}
                    >
                      {task.done ? <Check className="size-4" /> : null}
                    </button>
                    <div className="min-w-0 flex-1">
                      <p className={task.done ? "text-muted line-through" : ""}>{task.title}</p>
                      <p className="text-sm tabular-nums text-muted">{formatMinutes(task.minutes)}</p>
                    </div>
                    <button type="button" className="text-sm text-muted" onClick={() => removeTask(task.id)}>
                      حذف
                    </button>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function dayTitle(key: string): string {
  const [y, m, d] = key.split("-").map(Number);
  return new Date(y ?? 2026, (m ?? 1) - 1, d ?? 1).toLocaleDateString("ar", {
    weekday: "long",
    day: "numeric",
    month: "long",
  });
}

function LockScreen({
  device,
  lock,
  now,
  onOpen,
  onSwitch,
  onPlay,
  notice,
}: {
  device: DeviceId;
  lock: LockInfo;
  now: number;
  onOpen: (id: string) => void;
  onSwitch: () => void;
  onPlay: () => void;
  notice: (text: string) => void;
}) {
  const wall = useFocus((s) => s.wallpapers[device]);
  const allowed = useFocus((s) => s.allowed);
  const pomo = useFocus((s) => s.pomo);
  const tamperNote = useFocus((s) => s.tamperNote);
  const startPomo = useFocus((s) => s.startPomo);
  const wallName = WALLPAPERS.find((item) => item.id === wall)?.name ?? "";
  const blocked = CATALOG.filter((app) => !allowed.some((item) => item.id === app.id));
  return (
    <div className={`wall wall-${wall} fixed inset-0 z-40 flex items-center justify-center p-4`} role="dialog" aria-modal="true" aria-label="الجهازان مقفلان">
      <div className="w-full max-w-md rounded-3xl bg-bg px-6 py-8 text-center">
        <p className="text-sm text-muted">الجهازان مقفلان · {deviceName(device)} · خلفية {wallName}</p>
        <p className="mt-4 text-6xl font-medium tabular-nums tracking-tight text-paper sm:text-7xl">{formatRemain(lock.remainingMs)}</p>
        <p className="mt-3 text-lg text-paper">{lock.label}</p>
        <p className="mt-1 text-sm text-muted">ينتهي عند {lock.endsAt ? clockFace(lock.endsAt).slice(0, 5) : "—"} · الساعة الداخلية {clockFace(now)}</p>
        <div className="mx-auto my-6 h-px w-16 bg-brass" />
        {tamperNote ? <p className="text-sm text-brass">{tamperNote}</p> : null}
        {pomo.phase !== "idle" && pomo.phaseEndsAt ? (
          <p className="mt-3 text-sm tabular-nums text-paper">
            بومودورو {pomo.phase === "focus" ? "تركيز" : "استراحة"} · {formatRemain(pomo.phaseEndsAt - now)}
          </p>
        ) : (
          <button
            type="button"
            className="mt-3 text-sm text-brass underline decoration-from-font underline-offset-4"
            onClick={() => {
              startPomo(now);
              onPlay();
            }}
          >
            بدء بومودورو 25 + 5
          </button>
        )}
        <p className="mb-2 mt-8 text-sm text-muted">مسموح فتحها الآن</p>
        <div className="flex flex-wrap justify-center gap-2">
          {allowed.map((app) => (
            <button key={app.id} type="button" className="h-11 rounded-full border border-line bg-surface px-4 text-sm text-paper" onClick={() => onOpen(app.id)}>
              {app.name}
            </button>
          ))}
        </div>
        {blocked.length > 0 ? (
          <button
            type="button"
            className="mt-4 text-sm text-muted"
            onClick={() => {
              notice("هذه التطبيقات محجوبة طوال القفل، ولو فُتحت من مكان آخر تظهر سكينة فوقها.");
              onOpen(blocked[0]?.id ?? "games");
            }}
          >
            محجوب: {blocked.map((app) => app.name).slice(0, 4).join("، ")}
          </button>
        ) : null}
        <button type="button" className="mt-3 text-sm text-brass" onClick={onSwitch}>
          خلفية {deviceName(device === "phone" ? "laptop" : "phone")}
        </button>
      </div>
    </div>
  );
}

function AppLayer({
  id,
  locked,
  remaining,
  now,
  playing,
  onPlay,
  onClose,
  notice,
}: {
  id: string;
  locked: boolean;
  remaining: number;
  now: number | null;
  playing: LimitId | null;
  onPlay: (id: LimitId | null) => void;
  onClose: () => void;
  notice: (text: string) => void;
}) {
  const allowed = useFocus((s) => s.allowed);
  const name = allowed.find((app) => app.id === id)?.name ?? CATALOG.find((app) => app.id === id)?.name ?? "تطبيق";
  return (
    <div className="fixed inset-0 z-40 flex flex-col bg-bg text-fg">
      {locked ? (
        <div className="flex items-center justify-between gap-3 border-b border-line bg-surface px-4 py-2 text-sm">
          <span className="tabular-nums">متبقٍ على القفل {formatRemain(remaining)}</span>
          <button type="button" className="h-11 px-2" onClick={onClose}>
            العودة إلى القفل
          </button>
        </div>
      ) : (
        <div className="flex items-center justify-between border-b border-line px-4 py-2">
          <h2 className="text-base font-medium">{name}</h2>
          <button type="button" className="h-11 px-2 text-sm" onClick={onClose}>
            إغلاق
          </button>
        </div>
      )}
      <div className="min-h-0 flex-1 overflow-y-auto">
        <DeviceApp id={id} name={name} now={now} playing={playing} onPlay={onPlay} notice={notice} />
      </div>
    </div>
  );
}

function DeviceApp({
  id,
  name,
  now,
  playing,
  onPlay,
  notice,
}: {
  id: string;
  name: string;
  now: number | null;
  playing: LimitId | null;
  onPlay: (id: LimitId | null) => void;
  notice: (text: string) => void;
}) {
  if (id === "youtube") return <VideoApp limitId="shorts" title="يوتيوب" longLabel="الرئيسية" shortLabel="شورتس" now={now} playing={playing} onPlay={onPlay} />;
  if (id === "instagram") return <VideoApp limitId="reels" title="إنستغرام" longLabel="المنشورات" shortLabel="ريلز" now={now} playing={playing} onPlay={onPlay} />;
  if (id === "tiktok") return <VideoApp limitId="tiktok" title="تيك توك" longLabel="حسابات بلا تشغيل" shortLabel="المقاطع" now={now} playing={playing} onPlay={onPlay} defaultShort />;
  if (id === "browser") return <BrowserPane now={now} playing={playing} onPlay={onPlay} notice={notice} />;
  if (id === "call") return <CallPane />;
  if (id === "sms") return <SmsPane />;
  if (id === "maps") return <MapPane />;
  if (id === "notes") return <NotesPane />;
  if (id === "games") {
    return (
      <div className="p-6">
        <h3 className="text-lg font-medium">الألعاب</h3>
        <p className="mt-2 text-sm text-muted">متاحة ما دام الجهاز مفتوحاً. أثناء القفل لا تُفتح إلا إذا أضفتها إلى المسموح.</p>
      </div>
    );
  }
  return (
    <div className="p-6">
      <h3 className="text-lg font-medium">{name}</h3>
      <p className="mt-2 text-sm text-muted">تطبيق مسموح أثناء القفل. لا يُحسب من وقت المقاطع القصيرة.</p>
    </div>
  );
}

function VideoApp({
  limitId,
  title,
  longLabel,
  shortLabel,
  now,
  playing,
  onPlay,
  defaultShort,
  initialSurface = "app",
}: {
  limitId: LimitId;
  title: string;
  longLabel: string;
  shortLabel: string;
  now: number | null;
  playing: LimitId | null;
  onPlay: (id: LimitId | null) => void;
  defaultShort?: boolean;
  initialSurface?: "app" | "web";
}) {
  const [surface, setSurface] = useState<"app" | "web">(initialSurface);
  const [mode, setMode] = useState<"long" | "short">(defaultShort ? "short" : "long");
  return (
    <div className="flex flex-col gap-4 p-4">
      <div className="flex items-center justify-between gap-3">
        <h3 className="text-lg font-medium">{title}</h3>
        <div className="flex rounded-xl border border-line p-1 text-sm">
          {(["app", "web"] as const).map((item) => (
            <button key={item} type="button" className={`h-9 rounded-lg px-3 ${surface === item ? "bg-brass text-bg" : "text-muted"}`} onClick={() => setSurface(item)}>
              {item === "app" ? "التطبيق" : "الويب"}
            </button>
          ))}
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <button type="button" className={mode === "long" ? primary : ghost} onClick={() => { setMode("long"); onPlay(null); }}>
          {longLabel}
        </button>
        <button type="button" className={mode === "short" ? primary : ghost} onClick={() => setMode("short")}>
          {shortLabel}
        </button>
      </div>
      {mode === "long" ? (
        <ul className="flex flex-col gap-2">
          {["شرح طويل · 42 د", "محاضرة · 28 د", "مقابلة · 16 د"].map((item) => (
            <li key={item} className="rounded-xl border border-line bg-surface px-4 py-3 text-sm">
              {item}
              <p className="text-muted">لا يُحسب من حد المقاطع القصيرة</p>
            </li>
          ))}
        </ul>
      ) : (
        <ShortStage id={limitId} surface={surface} now={now} playing={playing === limitId} onPlay={onPlay} />
      )}
    </div>
  );
}

function ShortStage({
  id,
  surface,
  now,
  playing,
  onPlay,
}: {
  id: LimitId;
  surface: "app" | "web";
  now: number | null;
  playing: boolean;
  onPlay: (id: LimitId | null) => void;
}) {
  const rule = useFocus((s) => s.limits.find((item) => item.id === id));
  const consumeLimit = useFocus((s) => s.consumeLimit);
  if (!rule) return null;
  const cap = rule.minutesPerHour * 60_000;
  const exhausted = rule.usedMs >= cap;
  return (
    <div className="rounded-2xl border border-line bg-surface p-4">
      <p className="text-sm text-muted">
        {surface === "web" ? "نسخة الويب" : "نسخة التطبيق"} · الرصيد مشترك · متبقٍ {formatRemain(Math.max(0, cap - rule.usedMs))}
      </p>
      {exhausted ? (
        <div className="mt-4 flex flex-col items-start gap-3">
          <p className="font-medium">المقاطع القصيرة متوقفة حتى الساعة التالية.</p>
          <p className="text-sm text-muted">يمكنك البقاء في البرنامج وقراءة المحتوى الطويل. تشغيل أي مقطع، من الويب أو التطبيق، يبقى مغلقاً.</p>
        </div>
      ) : (
        <div className="mt-4 flex flex-col gap-3">
          <div className={`grid h-48 place-items-center rounded-xl ${playing ? "bg-brass text-bg" : "bg-bg"}`}>
            <p className="text-sm">{playing ? "المقطع يعمل ويُحتسب من الساعة" : "المقطع متوقف"}</p>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button type="button" className={primary} onClick={() => onPlay(playing ? null : id)}>
              {playing ? "إيقاف" : "تشغيل"}
            </button>
            <button
              type="button"
              className={ghost}
              onClick={() => {
                if (now == null) return;
                consumeLimit(id, 60_000, now);
              }}
            >
              احتساب دقيقة
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function BrowserPane({
  now,
  playing,
  onPlay,
  notice,
}: {
  now: number | null;
  playing: LimitId | null;
  onPlay: (id: LimitId | null) => void;
  notice: (text: string) => void;
}) {
  const [url, setUrl] = useState("");
  const [target, setTarget] = useState("");
  const adult = target ? isAdultTarget(target) : false;
  const host = target.toLowerCase();
  return (
    <div className="flex min-h-full flex-col">
      <div className="flex gap-2 border-b border-line p-3">
        <input
          className={field}
          value={url}
          placeholder="ابحث أو أدخل موقعاً"
          aria-label="شريط العنوان"
          onChange={(event) => setUrl(event.target.value)}
          onKeyDown={(event) => {
            if (event.key === "Enter") setTarget(url);
          }}
        />
        <button type="button" className={ghost} onClick={() => setTarget(url)}>
          فتح
        </button>
      </div>
      <div className="px-3 pt-3">
        <IncognitoControl onBlock={() => notice("التصفح الخفي متوقف على هذا الجهاز ولا يُفتح من الويب ولا من التطبيق.")} />
      </div>
      <div className="flex-1 p-4">
        {!target ? <p className="text-sm text-muted">المتصفح العادي يعمل. النافذة الخاصة لا تعمل.</p> : null}
        {target && adult ? (
          <div className="flex flex-col items-center gap-3 py-16 text-center">
            <Ban className="size-8 text-brass" />
            <h3 className="text-xl font-medium">محجوب نهائياً</h3>
            <p className="max-w-sm text-sm text-muted">هذا العنوان ضمن المحتوى الإباحي أو الهنتاي. الحجب دائم ولا يُتجاوز من التصفح الخفي لأنه متوقف أصلاً.</p>
            <button type="button" className={ghost} onClick={() => { setTarget(""); setUrl(""); }}>
              رجوع
            </button>
          </div>
        ) : null}
        {target && !adult && /youtube|youtu\.be/.test(host) ? (
          <VideoApp limitId="shorts" title="يوتيوب على الويب" longLabel="فيديوهات طويلة" shortLabel="شورتس" now={now} playing={playing} onPlay={onPlay} initialSurface="web" />
        ) : null}
        {target && !adult && /instagram/.test(host) ? (
          <VideoApp limitId="reels" title="إنستغرام على الويب" longLabel="المنشورات" shortLabel="ريلز" now={now} playing={playing} onPlay={onPlay} initialSurface="web" />
        ) : null}
        {target && !adult && /tiktok/.test(host) ? (
          <VideoApp limitId="tiktok" title="تيك توك على الويب" longLabel="بدون تشغيل" shortLabel="المقاطع" now={now} playing={playing} onPlay={onPlay} initialSurface="web" defaultShort />
        ) : null}
        {target && !adult && !/youtube|youtu\.be|instagram|tiktok/.test(host) ? (
          <article className="rounded-2xl border border-line bg-surface p-4">
            <h3 className="font-medium">صفحة عادية</h3>
            <p className="mt-2 text-sm text-muted">هذا العنوان ليس ضمن الحجب الدائم ويمكن فتحه خارج وقت قفل الجهاز.</p>
          </article>
        ) : null}
      </div>
    </div>
  );
}

function CallPane() {
  const people = ["أحمد", "ليلى", "المنزل"];
  return (
    <ul className="flex flex-col gap-2 p-4">
      {people.map((name) => (
        <li key={name} className="flex items-center justify-between rounded-2xl border border-line bg-surface px-4 py-3">
          <span>{name}</span>
          <span className="inline-flex items-center gap-2 text-sm text-sage">
            <Phone className="size-4" /> اتصال
          </span>
        </li>
      ))}
    </ul>
  );
}

function SmsPane() {
  return (
    <div className="flex flex-col gap-3 p-4">
      <div className="max-w-xs rounded-2xl bg-surface px-4 py-3 text-sm">وصلت؟</div>
      <div className="ms-auto max-w-xs rounded-2xl bg-brass px-4 py-3 text-sm text-bg">أنا في التركيز حتى نهاية العدّاد.</div>
    </div>
  );
}

function MapPane() {
  return (
    <div className="p-4">
      <div className="relative grid h-80 place-items-center overflow-hidden rounded-2xl border border-line bg-surface-2">
        <div className="absolute inset-x-0 top-16 h-px bg-line" />
        <div className="absolute inset-x-0 top-40 h-px bg-line" />
        <div className="absolute inset-y-0 start-16 w-px bg-line" />
        <div className="absolute inset-y-0 start-40 w-px bg-line" />
        <div className="relative size-4 rounded-full bg-brass" />
      </div>
      <p className="mt-3 text-sm text-muted">أنت هنا. الاتجاهات الأساسية تبقى متاحة أثناء القفل.</p>
    </div>
  );
}

function NotesPane() {
  const notes = useFocus((s) => s.notes);
  const setNotes = useFocus((s) => s.setNotes);
  const [draft, setDraft] = useState(notes);
  return (
    <div className="p-4">
      <textarea
        className="min-h-64 w-full rounded-2xl border border-line bg-surface p-4 text-sm outline-none focus-visible:border-brass"
        value={draft}
        onChange={(event) => setDraft(event.target.value)}
        onBlur={() => setNotes(draft)}
        aria-label="ملاحظة"
      />
      <p className="mt-2 text-sm text-muted">تُحفظ الملاحظة عند مغادرة الحقل وتُنسخ إلى الجهاز الآخر.</p>
    </div>
  );
}
