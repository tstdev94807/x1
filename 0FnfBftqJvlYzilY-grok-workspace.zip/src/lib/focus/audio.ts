let ctx: AudioContext | null = null;
let file: HTMLAudioElement | null = null;
let clipUrl: string | null = null;

function stopGraph(): void {
  if (ctx) {
    void ctx.close();
    ctx = null;
  }
  if (file) {
    file.pause();
    file.src = "";
    file = null;
  }
}

export function setSoundClip(url: string | null): void {
  if (clipUrl && clipUrl.startsWith("blob:")) URL.revokeObjectURL(clipUrl);
  clipUrl = url;
}

export function soundClip(): string | null {
  return clipUrl;
}

export function stopSound(): void {
  stopGraph();
}

export async function startSound(kind: "rain" | "file"): Promise<void> {
  stopGraph();
  if (kind === "file") {
    if (!clipUrl) return;
    file = new Audio(clipUrl);
    file.loop = true;
    file.volume = 0.85;
    await file.play();
    return;
  }
  const audio = new AudioContext();
  ctx = audio;
  const seconds = 2;
  const buffer = audio.createBuffer(1, audio.sampleRate * seconds, audio.sampleRate);
  const data = buffer.getChannelData(0);
  let last = 0;
  for (let i = 0; i < data.length; i += 1) {
    const white = Math.random() * 2 - 1;
    last = (last + 0.02 * white) / 1.02;
    data[i] = last * 3.5;
  }
  const source = audio.createBufferSource();
  source.buffer = buffer;
  source.loop = true;
  const filter = audio.createBiquadFilter();
  filter.type = "lowpass";
  filter.frequency.value = 900;
  const gain = audio.createGain();
  gain.gain.value = 0.45;
  source.connect(filter);
  filter.connect(gain);
  gain.connect(audio.destination);
  source.start();
  await audio.resume();
}
