import { createServerFn } from "@tanstack/react-start";

export const getServerNow = createServerFn({ method: "GET" }).handler(async () => {
  return { now: Date.now() };
});
