import { create } from "zustand";
import { dayKeyFrom, FOCUS_MIN, HOUR_MS, nextPomo, PENALTY_MS, resolveLock, uid } from "./model";
import type { AllowedApp, DeviceId, LimitRule, Pomo, Schedule, SoundId, Task, Transport, WallpaperId } from "./model";

export const STORAGE_KEY = "sakeena.v1";

export type FocusState = {
  rev: number;
  ready: boolean;
  pairCode: string;
  transport: Transport;
  wallpapers: Record<DeviceId, WallpaperId>;
  allowed: AllowedApp[];
  limits: LimitRule[];
  schedules: Schedule[];
  tasks: Task[];
  notes: string;
  manualEndsAt: number | null;
  usage: Record<DeviceId, number>;
  usageDay: string;
  pomo: Pomo;
  tamperStrikes: number;
  tamperNote: string;
  lastSync: string;
  savedSkew: number;
};

export type Persisted = Omit<FocusState, "ready" | "manualEndsAt"> & {
  remainingMs: number;
  savedAtWall: number;
};

type Actions = {
  commit: (partial: Partial<FocusState> | ((state: FocusState) => Partial<FocusState>)) => void;
  applyPersisted: (snap: Persisted, manualEndsAt: number | null) => void;
  markReady: (patch?: Partial<FocusState>) => void;
  startManual: (minutes: number, now: number) => void;
  addSchedule: (schedule: Omit<Schedule, "id">) => void;
  toggleSchedule: (id: string) => void;
  removeSchedule: (id: string) => void;
  toggleAllowed: (id: string, name: string) => void;
  addCustomAllowed: (name: string) => void;
  setLimitMinutes: (id: LimitRule["id"], minutes: number) => void;
  consumeLimit: (id: LimitRule["id"], ms: number, now: number) => void;
  addTask: (task: Omit<Task, "id" | "done">) => void;
  toggleTask: (id: string) => void;
  removeTask: (id: string) => void;
  stampSeedDays: (today: string) => void;
  startPomo: (now: number) => void;
  stopPomo: () => void;
  setPomoCycles: (cycles: number) => void;
  setSound: (sound: SoundId, name?: string) => void;
  onTick: (deltaMs: number, now: number, playing: LimitRule["id"] | null, device: DeviceId, visible: boolean) => void;
  punishClock: (now: number, note: string) => void;
  setNotes: (notes: string) => void;
};

const seedLimits = (): LimitRule[] => [
  {
    id: "shorts",
    name: "يوتيوب شورتس",
    detail: "المقاطع القصيرة على التطبيق والويب",
    minutesPerHour: 10,
    usedMs: 4 * 60 * 1000,
    hourKey: 0,
  },
  {
    id: "reels",
    name: "إنستغرام ريلز",
    detail: "الريلز على التطبيق والويب",
    minutesPerHour: 10,
    usedMs: 0,
    hourKey: 0,
  },
  {
    id: "tiktok",
    name: "تيك توك",
    detail: "المقاطع القصيرة على التطبيق والويب",
    minutesPerHour: 10,
    usedMs: 0,
    hourKey: 0,
  },
];

export const initialState: FocusState = {
  rev: 1,
  ready: false,
  pairCode: "K7MQ2P",
  transport: "internet",
  wallpapers: { phone: "ink", laptop: "dune" },
  allowed: [
    { id: "call", name: "الاتصال" },
    { id: "sms", name: "الرسائل" },
    { id: "maps", name: "الخرائط" },
    { id: "notes", name: "الملاحظات" },
  ],
  limits: seedLimits(),
  schedules: [
    {
      id: "eve",
      label: "تركيز المساء",
      days: [0, 1, 2, 3, 4],
      start: "17:00",
      end: "19:00",
      enabled: false,
    },
  ],
  tasks: [
    { id: "read", title: "قراءة هادئة", day: "*", minutes: 17 * 60, done: false },
    { id: "walk", title: "تمرين قصير", day: "*", minutes: 18 * 60 + 30, done: true },
  ],
  notes: "فكرة الدرس في سطرين، بلا هاتف بجانب الكراسة.",
  manualEndsAt: null,
  usage: { phone: 72 * 60 * 1000, laptop: 125 * 60 * 1000 },
  usageDay: "",
  pomo: {
    cyclesPlanned: 4,
    cyclesDone: 0,
    phase: "idle",
    phaseEndsAt: null,
    sound: "rain",
    customSoundName: "",
  },
  tamperStrikes: 0,
  tamperNote: "",
  lastSync: "الجهازان على نفس القفل",
  savedSkew: 0,
};

function syncLine(state: FocusState, action: string): string {
  const via = state.transport === "bluetooth" ? "البلوتوث" : "الإنترنت";
  return `${action} · نُسخ عبر ${via}`;
}

export const useFocus = create<FocusState & Actions>((set, get) => ({
  ...initialState,
  commit: (partial) => {
    set((state) => {
      const patch = typeof partial === "function" ? partial(state) : partial;
      return { ...patch, rev: state.rev + 1 };
    });
  },
  applyPersisted: (snap, manualEndsAt) => {
    const { remainingMs: _remaining, savedAtWall: _saved, ...rest } = snap;
    set({
      ...initialState,
      ...rest,
      wallpapers: { ...initialState.wallpapers, ...rest.wallpapers },
      usage: { ...initialState.usage, ...rest.usage },
      pomo: { ...initialState.pomo, ...rest.pomo },
      allowed: rest.allowed ?? initialState.allowed,
      limits: rest.limits?.length ? rest.limits : initialState.limits,
      schedules: rest.schedules ?? initialState.schedules,
      tasks: rest.tasks ?? initialState.tasks,
      manualEndsAt,
      ready: true,
    });
  },
  markReady: (patch) => set({ ready: true, ...patch }),
  startManual: (minutes, now) => {
    const ms = Math.min(12 * 60, Math.max(1, Math.round(minutes))) * 60 * 1000;
    const state = get();
    const current = resolveLock(state.manualEndsAt, state.schedules, now);
    const base = current.endsAt && current.endsAt > now + ms ? current.endsAt : now + ms;
    get().commit({
      manualEndsAt: base,
      lastSync: syncLine(state, "بدأ القفل على الجهازين"),
    });
  },
  addSchedule: (schedule) => {
    const state = get();
    get().commit({
      schedules: [...state.schedules, { ...schedule, id: uid("sch") }],
      lastSync: syncLine(state, "أُضيف موعد قفل"),
    });
  },
  toggleSchedule: (id) => {
    const state = get();
    get().commit({
      schedules: state.schedules.map((item) => (item.id === id ? { ...item, enabled: !item.enabled } : item)),
      lastSync: syncLine(state, "تحدّث جدول القفل"),
    });
  },
  removeSchedule: (id) => {
    const state = get();
    get().commit({
      schedules: state.schedules.filter((item) => item.id !== id),
      lastSync: syncLine(state, "حُذف موعد قفل"),
    });
  },
  toggleAllowed: (id, name) => {
    const state = get();
    const has = state.allowed.some((app) => app.id === id);
    get().commit({
      allowed: has ? state.allowed.filter((app) => app.id !== id) : [...state.allowed, { id, name }],
      lastSync: syncLine(state, "تحدّثت قائمة المسموح"),
    });
  },
  addCustomAllowed: (name) => {
    const trimmed = name.trim();
    if (!trimmed) return;
    const state = get();
    get().commit({
      allowed: [...state.allowed, { id: uid("app"), name: trimmed }],
      lastSync: syncLine(state, "أُضيف تطبيق مسموح"),
    });
  },
  setLimitMinutes: (id, minutes) => {
    const cap = Math.min(60, Math.max(1, Math.round(minutes)));
    const state = get();
    get().commit({
      limits: state.limits.map((rule) => (rule.id === id ? { ...rule, minutesPerHour: cap } : rule)),
      lastSync: syncLine(state, "تحدّث حد المقاطع"),
    });
  },
  consumeLimit: (id, ms, now) => {
    const hourKey = Math.floor(now / HOUR_MS);
    const state = get();
    get().commit({
      limits: state.limits.map((rule) => {
        const fresh = rule.hourKey === hourKey || rule.hourKey === 0 ? rule : { ...rule, hourKey, usedMs: 0 };
        if (fresh.id !== id) return fresh.hourKey === hourKey ? fresh : { ...fresh, hourKey };
        const cap = fresh.minutesPerHour * 60_000;
        return { ...fresh, hourKey, usedMs: Math.min(cap, fresh.usedMs + ms) };
      }),
    });
  },
  addTask: (task) => {
    const state = get();
    get().commit({
      tasks: [...state.tasks, { ...task, id: uid("task"), done: false }],
      lastSync: syncLine(state, "أُضيفت مهمة"),
    });
  },
  toggleTask: (id) => {
    const state = get();
    get().commit({
      tasks: state.tasks.map((task) => (task.id === id ? { ...task, done: !task.done } : task)),
      lastSync: syncLine(state, "تحدّثت مهمة"),
    });
  },
  removeTask: (id) => {
    const state = get();
    get().commit({ tasks: state.tasks.filter((task) => task.id !== id) });
  },
  stampSeedDays: (today) => {
    set((state) => ({
      tasks: state.tasks.map((task) => (task.day === "*" ? { ...task, day: today } : task)),
      usageDay: state.usageDay || today,
    }));
  },
  startPomo: (now) => {
    const state = get();
    get().commit({
      pomo: {
        ...state.pomo,
        phase: "focus",
        cyclesDone: 0,
        phaseEndsAt: now + FOCUS_MIN * 60_000,
      },
      lastSync: syncLine(state, "بدأ مؤقت التركيز"),
    });
  },
  stopPomo: () => {
    const state = get();
    get().commit({
      pomo: { ...state.pomo, phase: "idle", phaseEndsAt: null },
    });
  },
  setPomoCycles: (cycles) => {
    const state = get();
    const next = Math.min(12, Math.max(1, Math.round(cycles)));
    if (state.pomo.phase !== "idle") return;
    get().commit({ pomo: { ...state.pomo, cyclesPlanned: next, cyclesDone: 0 } });
  },
  setSound: (sound, name) => {
    const state = get();
    get().commit({
      pomo: {
        ...state.pomo,
        sound,
        customSoundName: name ?? state.pomo.customSoundName,
      },
    });
  },
  setNotes: (notes) => {
    get().commit({ notes });
  },
  onTick: (deltaMs, now, playing, device, visible) => {
    const state = get();
    const today = dayKeyFrom(now);
    let usage = state.usage;
    let usageDay = state.usageDay;
    if (usageDay && usageDay !== today) {
      usage = { phone: 0, laptop: 0 };
      usageDay = today;
    } else if (!usageDay) {
      usageDay = today;
    }
    const lock = resolveLock(state.manualEndsAt, state.schedules, now);
    if (!lock.active && visible && deltaMs > 0 && deltaMs < 5000) {
      usage = { ...usage, [device]: usage[device] + deltaMs };
    }
    const hourKey = Math.floor(now / HOUR_MS);
    let limits = state.limits.map((rule) => {
      if (rule.hourKey === hourKey) return rule;
      if (rule.hourKey === 0) return { ...rule, hourKey };
      return { ...rule, hourKey, usedMs: 0 };
    });
    if (playing) {
      limits = limits.map((rule) => {
        if (rule.id !== playing) return rule;
        const cap = rule.minutesPerHour * 60_000;
        if (rule.usedMs >= cap) return rule;
        return { ...rule, usedMs: Math.min(cap, rule.usedMs + deltaMs) };
      });
    }
    let pomo = state.pomo;
    let guard = 0;
    while (guard < 4) {
      const stepped = nextPomo(pomo, now);
      if (!stepped) break;
      pomo = stepped;
      guard += 1;
    }
    const usageChanged = usage.phone !== state.usage.phone || usage.laptop !== state.usage.laptop || usageDay !== state.usageDay;
    const limitsChanged = limits.some((rule, index) => rule.usedMs !== state.limits[index]?.usedMs || rule.hourKey !== state.limits[index]?.hourKey);
    const pomoChanged = pomo.phase !== state.pomo.phase || pomo.phaseEndsAt !== state.pomo.phaseEndsAt || pomo.cyclesDone !== state.pomo.cyclesDone;
    if (!usageChanged && !limitsChanged && !pomoChanged) return;
    set({ usage, usageDay, limits, pomo, rev: state.rev + 1 });
  },
  punishClock: (now, note) => {
    const state = get();
    const lock = resolveLock(state.manualEndsAt, state.schedules, now);
    if (!lock.active) {
      get().commit({
        tamperStrikes: state.tamperStrikes + 1,
        tamperNote: "رُصد تغيير الساعة والجهاز غير مقفل. أثناء القفل يُتجاهل التغيير وتُضاف 15 دقيقة.",
      });
      return;
    }
    const base = lock.endsAt && lock.endsAt > now ? lock.endsAt : now;
    get().commit({
      manualEndsAt: base + PENALTY_MS,
      tamperStrikes: state.tamperStrikes + 1,
      tamperNote: note,
      lastSync: syncLine(state, "إنذار تلاعب بالساعة"),
    });
  },
}));

export function toPersisted(state: FocusState, now: number, wall: number): Persisted {
  const lock = resolveLock(state.manualEndsAt, state.schedules, now);
  const { ready: _ready, manualEndsAt: _manual, ...rest } = state;
  return {
    ...rest,
    remainingMs: lock.active ? lock.remainingMs : 0,
    savedAtWall: wall,
  };
}

export function loadPersisted(): Persisted | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Persisted;
    if (!parsed || typeof parsed.rev !== "number" || !parsed.pairCode) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function savePersisted(snap: Persisted): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(snap));
}
