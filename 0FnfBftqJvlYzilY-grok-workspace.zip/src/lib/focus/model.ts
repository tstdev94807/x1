export type DeviceId = "phone" | "laptop";
export type Transport = "internet" | "bluetooth";
export type WallpaperId = "ink" | "dune" | "grove" | "mist";
export type SoundId = "none" | "rain" | "quran" | "custom";
export type LimitId = "shorts" | "reels" | "tiktok";
export type TabId = "today" | "lock" | "limits" | "shield" | "pomo" | "day";

export const PENALTY_MS = 15 * 60 * 1000;
export const HOUR_MS = 60 * 60 * 1000;
export const FOCUS_MIN = 25;
export const BREAK_MIN = 5;

export type AllowedApp = { id: string; name: string };

export type LimitRule = {
  id: LimitId;
  name: string;
  detail: string;
  minutesPerHour: number;
  usedMs: number;
  hourKey: number;
};

export type Schedule = {
  id: string;
  label: string;
  days: number[];
  start: string;
  end: string;
  enabled: boolean;
};

export type Task = {
  id: string;
  title: string;
  /** "YYYY-MM-DD" or "*" meaning the current day until the client stamps it. */
  day: string;
  minutes: number;
  done: boolean;
};

export type Pomo = {
  cyclesPlanned: number;
  cyclesDone: number;
  phase: "idle" | "focus" | "break";
  phaseEndsAt: number | null;
  sound: SoundId;
  customSoundName: string;
};

export type LockInfo = {
  active: boolean;
  endsAt: number | null;
  reason: "manual" | "schedule" | null;
  label: string;
  remainingMs: number;
};

export const WALLPAPERS: { id: WallpaperId; name: string }[] = [
  { id: "ink", name: "ليل" },
  { id: "dune", name: "رمل" },
  { id: "grove", name: "زيتون" },
  { id: "mist", name: "ضباب" },
];

export const CATALOG: { id: string; name: string; kind: string }[] = [
  { id: "youtube", name: "يوتيوب", kind: "youtube" },
  { id: "instagram", name: "إنستغرام", kind: "instagram" },
  { id: "tiktok", name: "تيك توك", kind: "tiktok" },
  { id: "browser", name: "المتصفح", kind: "browser" },
  { id: "games", name: "الألعاب", kind: "games" },
  { id: "call", name: "الاتصال", kind: "call" },
  { id: "sms", name: "الرسائل", kind: "sms" },
  { id: "maps", name: "الخرائط", kind: "maps" },
  { id: "notes", name: "الملاحظات", kind: "notes" },
];

export const WEEK: { d: number; label: string }[] = [
  { d: 6, label: "سبت" },
  { d: 0, label: "أحد" },
  { d: 1, label: "إثن" },
  { d: 2, label: "ثلا" },
  { d: 3, label: "أرب" },
  { d: 4, label: "خمي" },
  { d: 5, label: "جمع" },
];

const ADULT_WORDS = [
  "porn",
  "porno",
  "hentai",
  "xnxx",
  "xvideos",
  "xhamster",
  "pornhub",
  "redtube",
  "youporn",
  "rule34",
  "hanime",
  "nhentai",
  "spankbang",
  "faphouse",
  "ehentai",
  "هنتاي",
  "اباح",
  "سكس",
];

export function isAdultTarget(input: string): boolean {
  const raw = input.trim().toLowerCase();
  if (!raw) return false;
  const candidates = [raw];
  try {
    const url = new URL(raw.includes("://") ? raw : `https://${raw}`);
    candidates.push(`${url.hostname}${url.pathname}${url.search}`.toLowerCase());
  } catch {
    /* Punycode or odd hosts still get judged from the raw text. */
  }
  return candidates.some((hay) => {
    if (ADULT_WORDS.some((word) => hay.includes(word))) return true;
    return hay.split(/[^a-z0-9\u0600-\u06ff]+/).includes("xxx");
  });
}

export function parseHM(value: string): number | null {
  const match = /^(\d{1,2}):(\d{2})$/.exec(value);
  if (!match) return null;
  const h = Number(match[1]);
  const m = Number(match[2]);
  if (h > 23 || m > 59) return null;
  return h * 60 + m;
}

export function formatMinutes(total: number): string {
  const clamped = ((Math.floor(total) % 1440) + 1440) % 1440;
  const h = Math.floor(clamped / 60);
  const m = clamped % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}

export function formatRemain(ms: number): string {
  const s = Math.max(0, Math.ceil(ms / 1000));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
  return `${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
}

export function formatUsage(ms: number): { h: number; m: number } {
  const total = Math.max(0, Math.floor(ms / 60000));
  return { h: Math.floor(total / 60), m: total % 60 };
}

export function dayKeyFrom(epoch: number): string {
  const d = new Date(epoch);
  const y = d.getFullYear();
  const mo = String(d.getMonth() + 1).padStart(2, "0");
  const da = String(d.getDate()).padStart(2, "0");
  return `${y}-${mo}-${da}`;
}

export function shiftDay(key: string, delta: number): string {
  const [y, m, d] = key.split("-").map(Number);
  const date = new Date(y, (m ?? 1) - 1, d ?? 1);
  date.setDate(date.getDate() + delta);
  return dayKeyFrom(date.getTime());
}

export function weekday(key: string): number {
  const [y, m, d] = key.split("-").map(Number);
  return new Date(y, (m ?? 1) - 1, d ?? 1).getDay();
}

function atMinute(now: number, minute: number, dayShift: number): number {
  const d = new Date(now);
  d.setDate(d.getDate() + dayShift);
  d.setHours(Math.floor(minute / 60), minute % 60, 0, 0);
  return d.getTime();
}

export function scheduleEnd(schedule: Schedule, now: number): number | null {
  if (!schedule.enabled) return null;
  const start = parseHM(schedule.start);
  const end = parseHM(schedule.end);
  if (start == null || end == null || start === end) return null;
  const d = new Date(now);
  const today = d.getDay();
  const mins = d.getHours() * 60 + d.getMinutes();
  const wraps = end < start;
  const yesterday = new Date(d);
  yesterday.setDate(d.getDate() - 1);
  const fromYesterday = wraps && schedule.days.includes(yesterday.getDay()) && mins < end;
  const fromToday =
    schedule.days.includes(today) && (wraps ? mins >= start : mins >= start && mins < end);
  if (!fromToday && !fromYesterday) return null;
  if (fromYesterday || !wraps) return atMinute(now, end, 0);
  return atMinute(now, end, 1);
}

export function resolveLock(manualEndsAt: number | null, schedules: Schedule[], now: number): LockInfo {
  let endsAt: number | null = manualEndsAt != null && manualEndsAt > now ? manualEndsAt : null;
  let reason: LockInfo["reason"] = endsAt ? "manual" : null;
  let label = "قفل يدوي";
  for (const schedule of schedules) {
    const end = scheduleEnd(schedule, now);
    if (end != null && end > now && (endsAt == null || end > endsAt)) {
      endsAt = end;
      reason = "schedule";
      label = schedule.label.trim() || "قفل مجدول";
    }
  }
  return {
    active: endsAt != null,
    endsAt,
    reason,
    label,
    remainingMs: endsAt == null ? 0 : endsAt - now,
  };
}

export function restoreRemaining(input: {
  remainingMs: number;
  savedAtWall: number;
  nowWall: number;
}): { remainingMs: number; tamper: boolean } {
  if (input.remainingMs <= 0) return { remainingMs: 0, tamper: false };
  const delta = input.nowWall - input.savedAtWall;
  if (delta < -3000) return { remainingMs: input.remainingMs + PENALTY_MS, tamper: true };
  return { remainingMs: Math.max(0, input.remainingMs - delta), tamper: false };
}

export function correctRemaining(input: {
  remainingMs: number;
  savedAtWall: number;
  savedSkew: number;
  nowWall: number;
  skew: number;
}): { remainingMs: number; cheated: boolean } {
  const local = restoreRemaining(input).remainingMs;
  const trueElapsed = input.nowWall - input.skew - (input.savedAtWall - input.savedSkew);
  const corrected = input.remainingMs - trueElapsed;
  const forwardCheat = corrected > local + 10_000;
  const backwardCheat = input.skew < -20_000 && input.remainingMs > 0 && corrected > 0;
  if (forwardCheat || backwardCheat) {
    return { remainingMs: Math.max(0, corrected) + PENALTY_MS, cheated: true };
  }
  return { remainingMs: Math.max(0, corrected), cheated: false };
}

export function nextPomo(pomo: Pomo, now: number): Pomo | null {
  if (pomo.phase === "idle" || pomo.phaseEndsAt == null || now < pomo.phaseEndsAt) return null;
  if (pomo.phase === "focus") {
    return { ...pomo, phase: "break", phaseEndsAt: now + BREAK_MIN * 60_000 };
  }
  const cyclesDone = pomo.cyclesDone + 1;
  if (cyclesDone >= pomo.cyclesPlanned) {
    return { ...pomo, phase: "idle", phaseEndsAt: null, cyclesDone };
  }
  return {
    ...pomo,
    cyclesDone,
    phase: "focus",
    phaseEndsAt: now + FOCUS_MIN * 60_000,
  };
}

export function uid(prefix: string): string {
  return `${prefix}-${Math.random().toString(36).slice(2, 8)}`;
}
