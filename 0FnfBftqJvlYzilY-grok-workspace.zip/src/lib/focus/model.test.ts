import assert from "node:assert/strict";
import test from "node:test";
import {
  correctRemaining,
  isAdultTarget,
  PENALTY_MS,
  resolveLock,
  restoreRemaining,
  scheduleEnd,
} from "./model.ts";

test("adult filter catches porn and hentai hosts without broad false positives", () => {
  assert.equal(isAdultTarget("pornhub.com"), true);
  assert.equal(isAdultTarget("https://nhentai.net/g/1"), true);
  assert.equal(isAdultTarget("سكس.example"), true);
  assert.equal(isAdultTarget("xxx.com"), true);
  assert.equal(isAdultTarget("wikipedia.org"), false);
  assert.equal(isAdultTarget("sussex.ac.uk"), false);
  assert.equal(isAdultTarget("example.com/notes"), false);
});

test("schedule window resolves to the same evening on both devices", () => {
  const now = new Date(2026, 9, 22, 17, 30, 0, 0).getTime();
  const end = scheduleEnd(
    { id: "s", label: "مساء", days: [4], start: "17:00", end: "19:00", enabled: true },
    now,
  );
  assert.equal(end, new Date(2026, 9, 22, 19, 0, 0, 0).getTime());
  const lock = resolveLock(null, [
    { id: "s", label: "مساء", days: [4], start: "17:00", end: "19:00", enabled: true },
  ], now);
  assert.equal(lock.active, true);
  assert.equal(lock.reason, "schedule");
  assert.equal(lock.remainingMs, 90 * 60 * 1000);
});

test("manual lock outlasts a shorter schedule", () => {
  const now = new Date(2026, 9, 22, 17, 30, 0, 0).getTime();
  const lock = resolveLock(now + 4 * 60 * 60 * 1000, [
    { id: "s", label: "مساء", days: [4], start: "17:00", end: "19:00", enabled: true },
  ], now);
  assert.equal(lock.reason, "manual");
  assert.equal(lock.remainingMs, 4 * 60 * 60 * 1000);
});

test("clock rolled backward restores the full remaining time plus a penalty", () => {
  const restored = restoreRemaining({
    remainingMs: 30 * 60 * 1000,
    savedAtWall: 1_000_000,
    nowWall: 900_000,
  });
  assert.equal(restored.tamper, true);
  assert.equal(restored.remainingMs, 30 * 60 * 1000 + PENALTY_MS);
});

test("honest wait consumes remaining time", () => {
  const restored = restoreRemaining({
    remainingMs: 10 * 60 * 1000,
    savedAtWall: 1_000_000,
    nowWall: 1_000_000 + 4 * 60 * 1000,
  });
  assert.equal(restored.tamper, false);
  assert.equal(restored.remainingMs, 6 * 60 * 1000);
});

test("jumping the clock forward is corrected by network time and penalised", () => {
  const savedAtWall = 1_000_000;
  const remainingMs = 40 * 60 * 1000;
  const nowWall = savedAtWall + 3 * 60 * 60 * 1000;
  const skew = 3 * 60 * 60 * 1000;
  const corrected = correctRemaining({
    remainingMs,
    savedAtWall,
    savedSkew: 0,
    nowWall,
    skew,
  });
  assert.equal(corrected.cheated, true);
  assert.ok(corrected.remainingMs > remainingMs);
});
