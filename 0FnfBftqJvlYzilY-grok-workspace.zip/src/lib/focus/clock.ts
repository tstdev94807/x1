let originWall = 0;
let originPerf = 0;
let demoShift = 0;
let started = false;

export function initClock(): void {
  if (started) return;
  started = true;
  originWall = Date.now();
  originPerf = performance.now();
}

/** Monotonic wall estimate. Ignores later changes to the device clock. */
export function trustedWall(): number {
  if (!started) return Date.now();
  return originWall + (performance.now() - originPerf);
}

export function apparentWall(): number {
  return Date.now() + demoShift;
}

export function clockDrift(): number {
  if (!started) return 0;
  return apparentWall() - trustedWall();
}

export function nudgeDemoClock(ms: number): void {
  demoShift += ms;
}

export function resetDemoClock(): void {
  demoShift = 0;
}
