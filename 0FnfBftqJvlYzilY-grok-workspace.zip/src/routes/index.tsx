import { createFileRoute } from "@tanstack/react-router";
import { Sakeena } from "@/components/focus/screens";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <Sakeena />;
}
