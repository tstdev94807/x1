import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as CalendarDays, D as Aperture, E as Ban, S as Check, T as Bluetooth, _ as Gauge, a as Smartphone, b as Cloud, c as Plus, d as MessageSquare, f as MapPin, g as Globe, h as Laptop, i as StickyNote, l as Phone, m as LayoutGrid, n as TriangleAlert, o as Shield, p as Lock, r as Timer, s as RotateCcw, t as Tv, u as Music, v as Gamepad2, w as BookOpen, x as CloudRain, y as EyeOff } from "../_libs/lucide-react.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DAtaaCLH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var originWall = 0;
var originPerf = 0;
var demoShift = 0;
var started = false;
function initClock() {
	if (started) return;
	started = true;
	originWall = Date.now();
	originPerf = performance.now();
}
/** Monotonic wall estimate. Ignores later changes to the device clock. */
function trustedWall() {
	if (!started) return Date.now();
	return originWall + (performance.now() - originPerf);
}
function apparentWall() {
	return Date.now() + demoShift;
}
function clockDrift() {
	if (!started) return 0;
	return apparentWall() - trustedWall();
}
function nudgeDemoClock(ms) {
	demoShift += ms;
}
function resetDemoClock() {
	demoShift = 0;
}
var ctx = null;
var file = null;
var clipUrl = null;
function stopGraph() {
	if (ctx) {
		ctx.close();
		ctx = null;
	}
	if (file) {
		file.pause();
		file.src = "";
		file = null;
	}
}
function setSoundClip(url) {
	if (clipUrl && clipUrl.startsWith("blob:")) URL.revokeObjectURL(clipUrl);
	clipUrl = url;
}
function soundClip() {
	return clipUrl;
}
function stopSound() {
	stopGraph();
}
async function startSound(kind) {
	stopGraph();
	if (kind === "file") {
		if (!clipUrl) return;
		file = new Audio(clipUrl);
		file.loop = true;
		file.volume = .85;
		await file.play();
		return;
	}
	const audio = new AudioContext();
	ctx = audio;
	const buffer = audio.createBuffer(1, audio.sampleRate * 2, audio.sampleRate);
	const data = buffer.getChannelData(0);
	let last = 0;
	for (let i = 0; i < data.length; i += 1) {
		const white = Math.random() * 2 - 1;
		last = (last + .02 * white) / 1.02;
		data[i] = last * 3.5;
	}
	const source = audio.createBufferSource();
	source.buffer = buffer;
	source.loop = true;
	const filter = audio.createBiquadFilter();
	filter.type = "lowpass";
	filter.frequency.value = 900;
	const gain = audio.createGain();
	gain.gain.value = .45;
	source.connect(filter);
	filter.connect(gain);
	gain.connect(audio.destination);
	source.start();
	await audio.resume();
}
var PENALTY_MS = 9e5;
var HOUR_MS = 36e5;
var WALLPAPERS = [
	{
		id: "ink",
		name: "ليل"
	},
	{
		id: "dune",
		name: "رمل"
	},
	{
		id: "grove",
		name: "زيتون"
	},
	{
		id: "mist",
		name: "ضباب"
	}
];
var CATALOG = [
	{
		id: "youtube",
		name: "يوتيوب",
		kind: "youtube"
	},
	{
		id: "instagram",
		name: "إنستغرام",
		kind: "instagram"
	},
	{
		id: "tiktok",
		name: "تيك توك",
		kind: "tiktok"
	},
	{
		id: "browser",
		name: "المتصفح",
		kind: "browser"
	},
	{
		id: "games",
		name: "الألعاب",
		kind: "games"
	},
	{
		id: "call",
		name: "الاتصال",
		kind: "call"
	},
	{
		id: "sms",
		name: "الرسائل",
		kind: "sms"
	},
	{
		id: "maps",
		name: "الخرائط",
		kind: "maps"
	},
	{
		id: "notes",
		name: "الملاحظات",
		kind: "notes"
	}
];
var WEEK = [
	{
		d: 6,
		label: "سبت"
	},
	{
		d: 0,
		label: "أحد"
	},
	{
		d: 1,
		label: "إثن"
	},
	{
		d: 2,
		label: "ثلا"
	},
	{
		d: 3,
		label: "أرب"
	},
	{
		d: 4,
		label: "خمي"
	},
	{
		d: 5,
		label: "جمع"
	}
];
var ADULT_WORDS = [
	"porn",
	"porno",
	"hentai",
	"xnxx",
	"xvideos",
	"xhamster",
	"pornhub",
	"redtube",
	"youporn",
	"rule34",
	"hanime",
	"nhentai",
	"spankbang",
	"faphouse",
	"ehentai",
	"هنتاي",
	"اباح",
	"سكس"
];
function isAdultTarget(input) {
	const raw = input.trim().toLowerCase();
	if (!raw) return false;
	const candidates = [raw];
	try {
		const url = new URL(raw.includes("://") ? raw : `https://${raw}`);
		candidates.push(`${url.hostname}${url.pathname}${url.search}`.toLowerCase());
	} catch {}
	return candidates.some((hay) => {
		if (ADULT_WORDS.some((word) => hay.includes(word))) return true;
		return hay.split(/[^a-z0-9\u0600-\u06ff]+/).includes("xxx");
	});
}
function parseHM(value) {
	const match = /^(\d{1,2}):(\d{2})$/.exec(value);
	if (!match) return null;
	const h = Number(match[1]);
	const m = Number(match[2]);
	if (h > 23 || m > 59) return null;
	return h * 60 + m;
}
function formatMinutes(total) {
	const clamped = (Math.floor(total) % 1440 + 1440) % 1440;
	const h = Math.floor(clamped / 60);
	const m = clamped % 60;
	return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}
function formatRemain(ms) {
	const s = Math.max(0, Math.ceil(ms / 1e3));
	const h = Math.floor(s / 3600);
	const m = Math.floor(s % 3600 / 60);
	const sec = s % 60;
	if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
	return `${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
}
function formatUsage(ms) {
	const total = Math.max(0, Math.floor(ms / 6e4));
	return {
		h: Math.floor(total / 60),
		m: total % 60
	};
}
function dayKeyFrom(epoch) {
	const d = new Date(epoch);
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function shiftDay(key, delta) {
	const [y, m, d] = key.split("-").map(Number);
	const date = new Date(y, (m ?? 1) - 1, d ?? 1);
	date.setDate(date.getDate() + delta);
	return dayKeyFrom(date.getTime());
}
function weekday(key) {
	const [y, m, d] = key.split("-").map(Number);
	return new Date(y, (m ?? 1) - 1, d ?? 1).getDay();
}
function atMinute(now, minute, dayShift) {
	const d = new Date(now);
	d.setDate(d.getDate() + dayShift);
	d.setHours(Math.floor(minute / 60), minute % 60, 0, 0);
	return d.getTime();
}
function scheduleEnd(schedule, now) {
	if (!schedule.enabled) return null;
	const start = parseHM(schedule.start);
	const end = parseHM(schedule.end);
	if (start == null || end == null || start === end) return null;
	const d = new Date(now);
	const today = d.getDay();
	const mins = d.getHours() * 60 + d.getMinutes();
	const wraps = end < start;
	const yesterday = new Date(d);
	yesterday.setDate(d.getDate() - 1);
	const fromYesterday = wraps && schedule.days.includes(yesterday.getDay()) && mins < end;
	if (!(schedule.days.includes(today) && (wraps ? mins >= start : mins >= start && mins < end)) && !fromYesterday) return null;
	if (fromYesterday || !wraps) return atMinute(now, end, 0);
	return atMinute(now, end, 1);
}
function resolveLock(manualEndsAt, schedules, now) {
	let endsAt = manualEndsAt != null && manualEndsAt > now ? manualEndsAt : null;
	let reason = endsAt ? "manual" : null;
	let label = "قفل يدوي";
	for (const schedule of schedules) {
		const end = scheduleEnd(schedule, now);
		if (end != null && end > now && (endsAt == null || end > endsAt)) {
			endsAt = end;
			reason = "schedule";
			label = schedule.label.trim() || "قفل مجدول";
		}
	}
	return {
		active: endsAt != null,
		endsAt,
		reason,
		label,
		remainingMs: endsAt == null ? 0 : endsAt - now
	};
}
function restoreRemaining(input) {
	if (input.remainingMs <= 0) return {
		remainingMs: 0,
		tamper: false
	};
	const delta = input.nowWall - input.savedAtWall;
	if (delta < -3e3) return {
		remainingMs: input.remainingMs + PENALTY_MS,
		tamper: true
	};
	return {
		remainingMs: Math.max(0, input.remainingMs - delta),
		tamper: false
	};
}
function correctRemaining(input) {
	const local = restoreRemaining(input).remainingMs;
	const trueElapsed = input.nowWall - input.skew - (input.savedAtWall - input.savedSkew);
	const corrected = input.remainingMs - trueElapsed;
	const forwardCheat = corrected > local + 1e4;
	const backwardCheat = input.skew < -2e4 && input.remainingMs > 0 && corrected > 0;
	if (forwardCheat || backwardCheat) return {
		remainingMs: Math.max(0, corrected) + PENALTY_MS,
		cheated: true
	};
	return {
		remainingMs: Math.max(0, corrected),
		cheated: false
	};
}
function nextPomo(pomo, now) {
	if (pomo.phase === "idle" || pomo.phaseEndsAt == null || now < pomo.phaseEndsAt) return null;
	if (pomo.phase === "focus") return {
		...pomo,
		phase: "break",
		phaseEndsAt: now + 3e5
	};
	const cyclesDone = pomo.cyclesDone + 1;
	if (cyclesDone >= pomo.cyclesPlanned) return {
		...pomo,
		phase: "idle",
		phaseEndsAt: null,
		cyclesDone
	};
	return {
		...pomo,
		cyclesDone,
		phase: "focus",
		phaseEndsAt: now + 15e5
	};
}
function uid(prefix) {
	return `${prefix}-${Math.random().toString(36).slice(2, 8)}`;
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getServerNow = createServerFn({ method: "GET" }).handler(createSsrRpc("00e823cecaae52c5c83ff22b3f1139116ce0152d73327ada89bbdf9363fdb4d0"));
var STORAGE_KEY = "sakeena.v1";
var seedLimits = () => [
	{
		id: "shorts",
		name: "يوتيوب شورتس",
		detail: "المقاطع القصيرة على التطبيق والويب",
		minutesPerHour: 10,
		usedMs: 24e4,
		hourKey: 0
	},
	{
		id: "reels",
		name: "إنستغرام ريلز",
		detail: "الريلز على التطبيق والويب",
		minutesPerHour: 10,
		usedMs: 0,
		hourKey: 0
	},
	{
		id: "tiktok",
		name: "تيك توك",
		detail: "المقاطع القصيرة على التطبيق والويب",
		minutesPerHour: 10,
		usedMs: 0,
		hourKey: 0
	}
];
var initialState = {
	rev: 1,
	ready: false,
	pairCode: "K7MQ2P",
	transport: "internet",
	wallpapers: {
		phone: "ink",
		laptop: "dune"
	},
	allowed: [
		{
			id: "call",
			name: "الاتصال"
		},
		{
			id: "sms",
			name: "الرسائل"
		},
		{
			id: "maps",
			name: "الخرائط"
		},
		{
			id: "notes",
			name: "الملاحظات"
		}
	],
	limits: seedLimits(),
	schedules: [{
		id: "eve",
		label: "تركيز المساء",
		days: [
			0,
			1,
			2,
			3,
			4
		],
		start: "17:00",
		end: "19:00",
		enabled: false
	}],
	tasks: [{
		id: "read",
		title: "قراءة هادئة",
		day: "*",
		minutes: 1020,
		done: false
	}, {
		id: "walk",
		title: "تمرين قصير",
		day: "*",
		minutes: 1110,
		done: true
	}],
	notes: "فكرة الدرس في سطرين، بلا هاتف بجانب الكراسة.",
	manualEndsAt: null,
	usage: {
		phone: 432e4,
		laptop: 75e5
	},
	usageDay: "",
	pomo: {
		cyclesPlanned: 4,
		cyclesDone: 0,
		phase: "idle",
		phaseEndsAt: null,
		sound: "rain",
		customSoundName: ""
	},
	tamperStrikes: 0,
	tamperNote: "",
	lastSync: "الجهازان على نفس القفل",
	savedSkew: 0
};
function syncLine(state, action) {
	return `${action} · نُسخ عبر ${state.transport === "bluetooth" ? "البلوتوث" : "الإنترنت"}`;
}
var useFocus = create((set, get) => ({
	...initialState,
	commit: (partial) => {
		set((state) => {
			return {
				...typeof partial === "function" ? partial(state) : partial,
				rev: state.rev + 1
			};
		});
	},
	applyPersisted: (snap, manualEndsAt) => {
		const { remainingMs: _remaining, savedAtWall: _saved, ...rest } = snap;
		set({
			...initialState,
			...rest,
			wallpapers: {
				...initialState.wallpapers,
				...rest.wallpapers
			},
			usage: {
				...initialState.usage,
				...rest.usage
			},
			pomo: {
				...initialState.pomo,
				...rest.pomo
			},
			allowed: rest.allowed ?? initialState.allowed,
			limits: rest.limits?.length ? rest.limits : initialState.limits,
			schedules: rest.schedules ?? initialState.schedules,
			tasks: rest.tasks ?? initialState.tasks,
			manualEndsAt,
			ready: true
		});
	},
	markReady: (patch) => set({
		ready: true,
		...patch
	}),
	startManual: (minutes, now) => {
		const ms = Math.min(720, Math.max(1, Math.round(minutes))) * 60 * 1e3;
		const state = get();
		const current = resolveLock(state.manualEndsAt, state.schedules, now);
		const base = current.endsAt && current.endsAt > now + ms ? current.endsAt : now + ms;
		get().commit({
			manualEndsAt: base,
			lastSync: syncLine(state, "بدأ القفل على الجهازين")
		});
	},
	addSchedule: (schedule) => {
		const state = get();
		get().commit({
			schedules: [...state.schedules, {
				...schedule,
				id: uid("sch")
			}],
			lastSync: syncLine(state, "أُضيف موعد قفل")
		});
	},
	toggleSchedule: (id) => {
		const state = get();
		get().commit({
			schedules: state.schedules.map((item) => item.id === id ? {
				...item,
				enabled: !item.enabled
			} : item),
			lastSync: syncLine(state, "تحدّث جدول القفل")
		});
	},
	removeSchedule: (id) => {
		const state = get();
		get().commit({
			schedules: state.schedules.filter((item) => item.id !== id),
			lastSync: syncLine(state, "حُذف موعد قفل")
		});
	},
	toggleAllowed: (id, name) => {
		const state = get();
		const has = state.allowed.some((app) => app.id === id);
		get().commit({
			allowed: has ? state.allowed.filter((app) => app.id !== id) : [...state.allowed, {
				id,
				name
			}],
			lastSync: syncLine(state, "تحدّثت قائمة المسموح")
		});
	},
	addCustomAllowed: (name) => {
		const trimmed = name.trim();
		if (!trimmed) return;
		const state = get();
		get().commit({
			allowed: [...state.allowed, {
				id: uid("app"),
				name: trimmed
			}],
			lastSync: syncLine(state, "أُضيف تطبيق مسموح")
		});
	},
	setLimitMinutes: (id, minutes) => {
		const cap = Math.min(60, Math.max(1, Math.round(minutes)));
		const state = get();
		get().commit({
			limits: state.limits.map((rule) => rule.id === id ? {
				...rule,
				minutesPerHour: cap
			} : rule),
			lastSync: syncLine(state, "تحدّث حد المقاطع")
		});
	},
	consumeLimit: (id, ms, now) => {
		const hourKey = Math.floor(now / HOUR_MS);
		const state = get();
		get().commit({ limits: state.limits.map((rule) => {
			const fresh = rule.hourKey === hourKey || rule.hourKey === 0 ? rule : {
				...rule,
				hourKey,
				usedMs: 0
			};
			if (fresh.id !== id) return fresh.hourKey === hourKey ? fresh : {
				...fresh,
				hourKey
			};
			const cap = fresh.minutesPerHour * 6e4;
			return {
				...fresh,
				hourKey,
				usedMs: Math.min(cap, fresh.usedMs + ms)
			};
		}) });
	},
	addTask: (task) => {
		const state = get();
		get().commit({
			tasks: [...state.tasks, {
				...task,
				id: uid("task"),
				done: false
			}],
			lastSync: syncLine(state, "أُضيفت مهمة")
		});
	},
	toggleTask: (id) => {
		const state = get();
		get().commit({
			tasks: state.tasks.map((task) => task.id === id ? {
				...task,
				done: !task.done
			} : task),
			lastSync: syncLine(state, "تحدّثت مهمة")
		});
	},
	removeTask: (id) => {
		const state = get();
		get().commit({ tasks: state.tasks.filter((task) => task.id !== id) });
	},
	stampSeedDays: (today) => {
		set((state) => ({
			tasks: state.tasks.map((task) => task.day === "*" ? {
				...task,
				day: today
			} : task),
			usageDay: state.usageDay || today
		}));
	},
	startPomo: (now) => {
		const state = get();
		get().commit({
			pomo: {
				...state.pomo,
				phase: "focus",
				cyclesDone: 0,
				phaseEndsAt: now + 15e5
			},
			lastSync: syncLine(state, "بدأ مؤقت التركيز")
		});
	},
	stopPomo: () => {
		const state = get();
		get().commit({ pomo: {
			...state.pomo,
			phase: "idle",
			phaseEndsAt: null
		} });
	},
	setPomoCycles: (cycles) => {
		const state = get();
		const next = Math.min(12, Math.max(1, Math.round(cycles)));
		if (state.pomo.phase !== "idle") return;
		get().commit({ pomo: {
			...state.pomo,
			cyclesPlanned: next,
			cyclesDone: 0
		} });
	},
	setSound: (sound, name) => {
		const state = get();
		get().commit({ pomo: {
			...state.pomo,
			sound,
			customSoundName: name ?? state.pomo.customSoundName
		} });
	},
	setNotes: (notes) => {
		get().commit({ notes });
	},
	onTick: (deltaMs, now, playing, device, visible) => {
		const state = get();
		const today = dayKeyFrom(now);
		let usage = state.usage;
		let usageDay = state.usageDay;
		if (usageDay && usageDay !== today) {
			usage = {
				phone: 0,
				laptop: 0
			};
			usageDay = today;
		} else if (!usageDay) usageDay = today;
		if (!resolveLock(state.manualEndsAt, state.schedules, now).active && visible && deltaMs > 0 && deltaMs < 5e3) usage = {
			...usage,
			[device]: usage[device] + deltaMs
		};
		const hourKey = Math.floor(now / HOUR_MS);
		let limits = state.limits.map((rule) => {
			if (rule.hourKey === hourKey) return rule;
			if (rule.hourKey === 0) return {
				...rule,
				hourKey
			};
			return {
				...rule,
				hourKey,
				usedMs: 0
			};
		});
		if (playing) limits = limits.map((rule) => {
			if (rule.id !== playing) return rule;
			const cap = rule.minutesPerHour * 6e4;
			if (rule.usedMs >= cap) return rule;
			return {
				...rule,
				usedMs: Math.min(cap, rule.usedMs + deltaMs)
			};
		});
		let pomo = state.pomo;
		let guard = 0;
		while (guard < 4) {
			const stepped = nextPomo(pomo, now);
			if (!stepped) break;
			pomo = stepped;
			guard += 1;
		}
		const usageChanged = usage.phone !== state.usage.phone || usage.laptop !== state.usage.laptop || usageDay !== state.usageDay;
		const limitsChanged = limits.some((rule, index) => rule.usedMs !== state.limits[index]?.usedMs || rule.hourKey !== state.limits[index]?.hourKey);
		const pomoChanged = pomo.phase !== state.pomo.phase || pomo.phaseEndsAt !== state.pomo.phaseEndsAt || pomo.cyclesDone !== state.pomo.cyclesDone;
		if (!usageChanged && !limitsChanged && !pomoChanged) return;
		set({
			usage,
			usageDay,
			limits,
			pomo,
			rev: state.rev + 1
		});
	},
	punishClock: (now, note) => {
		const state = get();
		const lock = resolveLock(state.manualEndsAt, state.schedules, now);
		if (!lock.active) {
			get().commit({
				tamperStrikes: state.tamperStrikes + 1,
				tamperNote: "رُصد تغيير الساعة والجهاز غير مقفل. أثناء القفل يُتجاهل التغيير وتُضاف 15 دقيقة."
			});
			return;
		}
		const base = lock.endsAt && lock.endsAt > now ? lock.endsAt : now;
		get().commit({
			manualEndsAt: base + PENALTY_MS,
			tamperStrikes: state.tamperStrikes + 1,
			tamperNote: note,
			lastSync: syncLine(state, "إنذار تلاعب بالساعة")
		});
	}
}));
function toPersisted(state, now, wall) {
	const lock = resolveLock(state.manualEndsAt, state.schedules, now);
	const { ready: _ready, manualEndsAt: _manual, ...rest } = state;
	return {
		...rest,
		remainingMs: lock.active ? lock.remainingMs : 0,
		savedAtWall: wall
	};
}
function loadPersisted() {
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		if (!parsed || typeof parsed.rev !== "number" || !parsed.pairCode) return null;
		return parsed;
	} catch {
		return null;
	}
}
function savePersisted(snap) {
	localStorage.setItem(STORAGE_KEY, JSON.stringify(snap));
}
var IDLE_LOCK = {
	active: false,
	endsAt: null,
	reason: null,
	label: "",
	remainingMs: 0
};
var DURATIONS = [
	1,
	15,
	25,
	45,
	60,
	120,
	240,
	480,
	720
];
var btn = "inline-flex h-11 items-center justify-center gap-2 rounded-xl px-4 text-sm font-medium transition-colors disabled:cursor-not-allowed disabled:opacity-40";
var primary = `${btn} bg-brass text-bg`;
var ghost = `${btn} border border-line bg-surface text-fg`;
var field = "h-11 w-full rounded-xl border border-line bg-bg px-3 text-sm text-fg outline-none focus-visible:border-brass";
var TABS = [
	{
		id: "today",
		label: "اليوم",
		icon: LayoutGrid
	},
	{
		id: "lock",
		label: "القفل",
		icon: Lock
	},
	{
		id: "limits",
		label: "الحدود",
		icon: Gauge
	},
	{
		id: "shield",
		label: "الدرع",
		icon: Shield
	},
	{
		id: "pomo",
		label: "بومودورو",
		icon: Timer
	},
	{
		id: "day",
		label: "الجدول",
		icon: CalendarDays
	}
];
function deviceName(device) {
	return device === "phone" ? "الهاتف" : "الحاسوب";
}
function otherDevice(device) {
	return device === "phone" ? "laptop" : "phone";
}
function usageText(ms) {
	const { h, m } = formatUsage(ms);
	return `${h} س ${String(m).padStart(2, "0")} د`;
}
function clockFace(epoch) {
	const date = new Date(epoch);
	return `${formatMinutes(date.getHours() * 60 + date.getMinutes())}:${String(date.getSeconds()).padStart(2, "0")}`;
}
function weekStart(key) {
	return shiftDay(key, -((weekday(key) + 1) % 7));
}
function onThisDay(task, selected, today) {
	if (task.day === selected) return true;
	return task.day === "*" && (today == null || selected === today || selected === "*");
}
function UsageFigure({ ms, large }) {
	const { h, m } = formatUsage(ms);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: large ? "text-6xl font-light tabular-nums tracking-tight" : "text-3xl font-light tabular-nums",
		children: [
			h,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-base text-muted",
				children: " س "
			}),
			String(m).padStart(2, "0"),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-base text-muted",
				children: " د"
			})
		]
	});
}
function Sakeena() {
	const state = useFocus();
	const [device, setDevice] = (0, import_react.useState)("laptop");
	const [tab, setTab] = (0, import_react.useState)("today");
	const [now, setNow] = (0, import_react.useState)(null);
	const [foreground, setForeground] = (0, import_react.useState)(null);
	const [playing, setPlaying] = (0, import_react.useState)(null);
	const [notice, setNotice] = (0, import_react.useState)(null);
	const playingRef = (0, import_react.useRef)(null);
	const deviceRef = (0, import_react.useRef)("phone");
	const latched = (0, import_react.useRef)(false);
	playingRef.current = playing;
	deviceRef.current = device;
	(0, import_react.useLayoutEffect)(() => {
		initClock();
		const trusted = trustedWall();
		setNow(trusted);
		const snap = loadPersisted();
		if (!snap) {
			const today = dayKeyFrom(trusted);
			useFocus.getState().stampSeedDays(today);
			useFocus.getState().markReady({ usageDay: today });
		} else {
			const restored = restoreRemaining({
				remainingMs: snap.remainingMs ?? 0,
				savedAtWall: snap.savedAtWall ?? Date.now(),
				nowWall: Date.now()
			});
			const manualEndsAt = restored.remainingMs > 1e3 ? trusted + restored.remainingMs : null;
			useFocus.getState().applyPersisted(snap, manualEndsAt);
			useFocus.getState().stampSeedDays(dayKeyFrom(trusted));
			if (restored.tamper) useFocus.setState((current) => ({
				tamperStrikes: current.tamperStrikes + 1,
				tamperNote: "بعد الإقلاع كانت الساعة متأخرة. أُعيد الوقت المتبقي وأُضيفت 15 دقيقة."
			}));
			verifyNetworkTime(snap, manualEndsAt);
		}
		let last = trustedWall();
		let bucket = 0;
		const timer = window.setInterval(() => {
			const tick = trustedWall();
			const delta = Math.min(5e3, Math.max(0, tick - last));
			last = tick;
			setNow(tick);
			const drift = clockDrift();
			if (Math.abs(drift) > 8e3) {
				if (!latched.current) {
					latched.current = true;
					const note = drift > 0 ? "رُصد تقديم ساعة الجهاز. القفل بقي على الساعة الداخلية وأُضيفت 15 دقيقة." : "رُصد تأخير ساعة الجهاز. أُضيفت 15 دقيقة ولم يُقبل الوقت الجديد.";
					useFocus.getState().punishClock(tick, note);
				}
			} else latched.current = false;
			bucket += delta;
			if (bucket >= 1e3) {
				const chunk = bucket;
				bucket = 0;
				useFocus.getState().onTick(chunk, tick, playingRef.current, deviceRef.current, document.visibilityState === "visible");
			} else useFocus.getState().onTick(0, tick, null, deviceRef.current, false);
		}, 500);
		let persistTimer = 0;
		const unsub = useFocus.subscribe((next) => {
			if (!next.ready) return;
			window.clearTimeout(persistTimer);
			persistTimer = window.setTimeout(() => {
				savePersisted(toPersisted(next, trustedWall(), Date.now()));
			}, 400);
		});
		const flush = () => {
			const current = useFocus.getState();
			if (!current.ready) return;
			savePersisted(toPersisted(current, trustedWall(), Date.now()));
		};
		const onStorage = (event) => {
			if (event.key !== "sakeena.v1" || !event.newValue) return;
			try {
				const incoming = JSON.parse(event.newValue);
				if (!incoming || incoming.rev <= useFocus.getState().rev) return;
				const trustedNow = trustedWall();
				const restored = restoreRemaining({
					remainingMs: incoming.remainingMs ?? 0,
					savedAtWall: incoming.savedAtWall ?? Date.now(),
					nowWall: Date.now()
				});
				useFocus.getState().applyPersisted(incoming, restored.remainingMs > 500 ? trustedNow + restored.remainingMs : null);
			} catch {}
		};
		window.addEventListener("storage", onStorage);
		window.addEventListener("pagehide", flush);
		return () => {
			window.clearInterval(timer);
			window.clearTimeout(persistTimer);
			unsub();
			window.removeEventListener("storage", onStorage);
			window.removeEventListener("pagehide", flush);
			stopSound();
		};
	}, []);
	const lock = now == null ? IDLE_LOCK : resolveLock(state.manualEndsAt, state.schedules, now);
	const allowedFront = foreground != null && state.allowed.some((app) => app.id === foreground);
	const showApp = foreground != null && (!lock.active || allowedFront);
	(0, import_react.useEffect)(() => {
		if (lock.active && foreground && !allowedFront) {
			setForeground(null);
			setPlaying(null);
			setNotice("أُغلق التطبيق لأنه ليس ضمن المسموح. القفل عاد إلى الأمام.");
		}
	}, [
		lock.active,
		foreground,
		allowedFront
	]);
	(0, import_react.useEffect)(() => {
		if (!lock.active) return;
		const onKey = (event) => {
			if (event.key === "Escape") event.preventDefault();
		};
		const onLeave = (event) => {
			event.preventDefault();
			event.returnValue = "";
		};
		window.addEventListener("keydown", onKey);
		window.addEventListener("beforeunload", onLeave);
		return () => {
			window.removeEventListener("keydown", onKey);
			window.removeEventListener("beforeunload", onLeave);
		};
	}, [lock.active]);
	(0, import_react.useEffect)(() => {
		if (state.pomo.phase === "idle") stopSound();
	}, [state.pomo.phase]);
	const strikes = state.tamperStrikes;
	const strikeBoot = (0, import_react.useRef)(true);
	(0, import_react.useEffect)(() => {
		if (strikeBoot.current) {
			strikeBoot.current = false;
			return;
		}
		if (state.tamperNote) setNotice(state.tamperNote);
	}, [strikes, state.tamperNote]);
	(0, import_react.useEffect)(() => {
		if (!playing) return;
		const rule = state.limits.find((item) => item.id === playing);
		if (rule && rule.usedMs >= rule.minutesPerHour * 6e4) {
			setPlaying(null);
			setNotice("نفد حد المقاطع القصيرة لهذه الساعة. يبقى استخدام التطبيق بدونها.");
		}
	}, [playing, state.limits]);
	(0, import_react.useEffect)(() => {
		if (!notice) return;
		const id = window.setTimeout(() => setNotice(null), 4200);
		return () => window.clearTimeout(id);
	}, [notice]);
	function openApp(id) {
		const trusted = trustedWall();
		const current = resolveLock(useFocus.getState().manualEndsAt, useFocus.getState().schedules, trusted);
		const allowed = useFocus.getState().allowed.some((app) => app.id === id);
		if (current.active && !allowed) {
			setForeground(null);
			setNotice("هذا التطبيق خارج قائمة المسموح. القفل يبقى فوقه.");
			return;
		}
		setForeground(id);
	}
	function playChosen() {
		const sound = useFocus.getState().pomo.sound;
		if (sound === "rain") {
			startSound("rain");
			return;
		}
		if ((sound === "quran" || sound === "custom") && soundClip()) {
			startSound("file").catch(() => setNotice("تعذّر تشغيل الملف. اختره مرة أخرى."));
			return;
		}
		if (sound === "quran") setNotice("اختر ملف تلاوة من جهازك. المؤقت يعمل والصوت ينتظر الملف.");
		if (sound === "custom") setNotice("اختر ملف الصوت الخاص. المؤقت يعمل بدونه حتى تضيفه.");
	}
	const twin = otherDevice(device);
	const total = state.usage.phone + state.usage.laptop;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				inert: lock.active || showApp ? true : void 0,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "sticky top-0 z-30 border-b border-line bg-bg",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto flex w-full max-w-6xl items-center justify-between gap-3 px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid size-10 place-items-center rounded-xl bg-surface-2",
									"aria-hidden": true,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-4 w-px bg-brass" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-lg font-medium leading-none",
									children: "سكينة"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-muted",
									children: "قفل واحد للجهازين"
								})] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex rounded-xl border border-line p-1",
								children: ["phone", "laptop"].map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: `inline-flex h-10 items-center gap-2 rounded-lg px-3 text-sm ${device === id ? "bg-brass text-bg" : "text-muted"}`,
									onClick: () => setDevice(id),
									children: [id === "phone" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Laptop, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: id === "phone" ? "هاتف" : "حاسوب" })]
								}, id))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto flex w-full max-w-6xl items-center justify-between gap-3 border-t border-line px-4 py-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "min-w-0 truncate text-muted",
								children: [
									deviceName(twin),
									" · ",
									usageText(state.usage[twin]),
									" · ",
									lock.active ? "مقفل مع هذا الجهاز" : "مفتوح"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "inline-flex shrink-0 items-center gap-2 text-sage",
								children: [state.transport === "internet" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cloud, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bluetooth, { className: "size-4" }), "متزامن"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "tabs mx-auto flex w-full max-w-6xl gap-2 overflow-x-auto px-4 pb-3",
							"aria-label": "أقسام سكينة",
							children: TABS.map((item) => {
								const Icon = item.icon;
								const on = tab === item.id;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: `inline-flex h-11 shrink-0 items-center gap-2 rounded-full px-4 text-sm ${on ? "bg-brass text-bg" : "bg-surface text-muted"}`,
									onClick: () => setTab(item.id),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), item.label]
								}, item.id);
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid w-full max-w-6xl items-start lg:grid-cols-[minmax(0,1fr)_18rem]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
						className: device === "phone" ? "mx-auto w-full max-w-md px-4 py-5" : "min-w-0 px-4 py-5",
						children: [
							tab === "today" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Today, {
								total,
								now,
								onOpen: openApp,
								onTab: setTab,
								device
							}) : null,
							tab === "lock" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockSettings, {
								now,
								notice: setNotice
							}) : null,
							tab === "limits" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Limits, {
								now,
								onOpen: openApp
							}) : null,
							tab === "shield" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldView, {
								now,
								notice: setNotice
							}) : null,
							tab === "pomo" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PomoView, {
								now,
								notice: setNotice,
								onPlay: playChosen
							}) : null,
							tab === "day" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Agenda, { now }) : null
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TwinCard, {
						device: twin,
						now,
						lock,
						onSwitch: () => setDevice(twin)
					})]
				})]
			}),
			lock.active && !showApp && now != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockScreen, {
				device,
				lock,
				now,
				onOpen: openApp,
				onSwitch: () => setDevice(twin),
				onPlay: playChosen,
				notice: setNotice
			}) : null,
			showApp && foreground ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppLayer, {
				id: foreground,
				locked: lock.active,
				remaining: lock.remainingMs,
				now,
				playing,
				onPlay: setPlaying,
				onClose: () => {
					setForeground(null);
					setPlaying(null);
				},
				notice: setNotice
			}) : null,
			notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-x-4 top-4 z-50 mx-auto max-w-md rounded-2xl border border-line bg-surface px-4 py-3 text-sm",
				role: "status",
				children: notice
			}) : null
		]
	});
}
async function verifyNetworkTime(snap, expectedEnd) {
	if ((snap.remainingMs ?? 0) <= 0) return;
	try {
		const t0 = Date.now();
		const result = await getServerNow();
		const skew = t0 + (Date.now() - t0) / 2 - result.now;
		if (useFocus.getState().manualEndsAt !== expectedEnd) return;
		useFocus.setState({ savedSkew: skew });
		const corrected = correctRemaining({
			remainingMs: snap.remainingMs,
			savedAtWall: snap.savedAtWall,
			savedSkew: snap.savedSkew ?? 0,
			nowWall: Date.now(),
			skew
		});
		if (useFocus.getState().manualEndsAt !== expectedEnd) return;
		const trusted = trustedWall();
		if (corrected.cheated) {
			useFocus.getState().commit({
				manualEndsAt: trusted + corrected.remainingMs,
				tamperStrikes: useFocus.getState().tamperStrikes + 1,
				tamperNote: "وقت الشبكة لا يطابق ساعة الجهاز. استُكمل القفل وأُضيفت 15 دقيقة.",
				lastSync: "نُسخ إنذار الساعة إلى الجهاز الآخر"
			});
			return;
		}
		useFocus.setState({ manualEndsAt: corrected.remainingMs > 1e3 ? trusted + corrected.remainingMs : null });
	} catch {
		if (!useFocus.getState().tamperNote) useFocus.setState({ tamperNote: "تعذّر التحقق من وقت الشبكة هذه المرة. القفل المحلي ما زال سارياً." });
	}
}
function TwinCard({ device, now, lock, onSwitch }) {
	const wall = useFocus((s) => s.wallpapers[device]);
	const usage = useFocus((s) => s.usage[device]);
	const name = WALLPAPERS.find((item) => item.id === wall)?.name ?? "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
		className: "sticky top-36 hidden px-4 py-5 lg:block",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: `wall wall-${wall} overflow-hidden rounded-3xl border border-line p-5`,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm opacity-70",
					children: deviceName(device)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-4xl font-light tabular-nums",
					children: lock.active && now != null ? formatRemain(lock.remainingMs) : usageText(usage)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm opacity-70",
					children: lock.active ? "نفس العدّاد على الجهازين" : `خلفية ${name}`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "mt-6 inline-flex h-11 w-full items-center justify-center rounded-xl bg-bg px-4 text-sm font-medium text-paper",
					onClick: onSwitch,
					children: ["الانتقال إلى ", deviceName(device)]
				})
			]
		})
	});
}
function Today({ total, now, onOpen, onTab, device }) {
	const usage = useFocus((s) => s.usage);
	const tasks = useFocus((s) => s.tasks);
	const toggleTask = useFocus((s) => s.toggleTask);
	const today = now == null ? null : dayKeyFrom(now);
	const openTasks = tasks.filter((task) => !task.done && onThisDay(task, today ?? "*", today));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: ["ما مضى اليوم على الجهازين وأنت تتصفح ", deviceName(device)]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UsageFigure, {
				ms: total,
				large: true
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl border border-line bg-surface p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "inline-flex items-center gap-2 text-sm text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, { className: "size-4" }), " الهاتف"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UsageFigure, { ms: usage.phone })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl border border-line bg-surface p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "inline-flex items-center gap-2 text-sm text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Laptop, { className: "size-4" }), " الحاسوب"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UsageFigure, { ms: usage.laptop })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-base font-medium",
							children: "مهام اليوم"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "text-sm text-brass",
							onClick: () => onTab("day"),
							children: "الجدول"
						})]
					}),
					openTasks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "لا مهام مفتوحة. أضف واحدة من الجدول بالدقيقة."
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-2",
						children: openTasks.map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "grid size-11 place-items-center rounded-xl border border-line",
								"aria-label": `إتمام ${task.title}`,
								onClick: () => toggleTask(task.id),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-3 rounded-sm border border-muted" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: task.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm tabular-nums text-muted",
								children: formatMinutes(task.minutes)
							})] })]
						}, task.id))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 text-base font-medium",
				children: "على الجهاز"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 gap-2",
				children: CATALOG.map((app) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: `${ghost} h-auto flex-col gap-2 py-3`,
					onClick: () => onOpen(app.id),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppIcon, { id: app.id }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs",
						children: app.name
					})]
				}, app.id))
			})] })
		]
	});
}
function AppIcon({ id }) {
	const cls = "size-5";
	if (id === "youtube") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tv, { className: cls });
	if (id === "instagram") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Aperture, { className: cls });
	if (id === "tiktok") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Music, { className: cls });
	if (id === "browser") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: cls });
	if (id === "games") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gamepad2, { className: cls });
	if (id === "call") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: cls });
	if (id === "sms") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquare, { className: cls });
	if (id === "maps") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: cls });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StickyNote, { className: cls });
}
function LockSettings({ now, notice }) {
	const schedules = useFocus((s) => s.schedules);
	const allowed = useFocus((s) => s.allowed);
	const transport = useFocus((s) => s.transport);
	const pairCode = useFocus((s) => s.pairCode);
	const wallpapers = useFocus((s) => s.wallpapers);
	const lastSync = useFocus((s) => s.lastSync);
	const commit = useFocus((s) => s.commit);
	const startManual = useFocus((s) => s.startManual);
	const addSchedule = useFocus((s) => s.addSchedule);
	const toggleSchedule = useFocus((s) => s.toggleSchedule);
	const removeSchedule = useFocus((s) => s.removeSchedule);
	const toggleAllowed = useFocus((s) => s.toggleAllowed);
	const addCustomAllowed = useFocus((s) => s.addCustomAllowed);
	const [minutes, setMinutes] = (0, import_react.useState)(25);
	const [label, setLabel] = (0, import_react.useState)("جلسة تركيز");
	const [start, setStart] = (0, import_react.useState)("17:00");
	const [end, setEnd] = (0, import_react.useState)("19:00");
	const [days, setDays] = (0, import_react.useState)([
		0,
		1,
		2,
		3,
		4
	]);
	const [armAdd, setArmAdd] = (0, import_react.useState)(false);
	const [armToggle, setArmToggle] = (0, import_react.useState)(null);
	const [customApp, setCustomApp] = (0, import_react.useState)("");
	function beginManual() {
		if (now == null) return;
		startManual(minutes, now);
		notice("الجهازان مقفلان الآن بنفس العدّاد.");
	}
	function beginSchedule() {
		if (days.length === 0) {
			notice("اختر يوماً واحداً على الأقل.");
			return;
		}
		const draft = {
			label,
			days,
			start,
			end,
			enabled: true
		};
		if (now != null && scheduleEnd({
			...draft,
			id: "tmp"
		}, now) && !armAdd) {
			setArmAdd(true);
			notice("هذا الموعد سيغلق الجهازين الآن. اضغط إضافة مرة أخرى للتأكيد.");
			return;
		}
		addSchedule(draft);
		setArmAdd(false);
		notice("نُسخ الموعد إلى الجهاز الآخر.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-base font-medium",
						children: "قفل يدوي"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "من دقيقة إلى 12 ساعة. يبدأ على الهاتف والحاسوب معاً ولا يُلغى قبل وقته."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 grid grid-cols-3 gap-2 sm:grid-cols-5",
						children: DURATIONS.map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `h-11 rounded-xl text-sm tabular-nums ${minutes === value ? "bg-brass text-bg" : "bg-bg text-fg"}`,
							onClick: () => setMinutes(value),
							children: value < 60 ? `${value} د` : `${value / 60} س`
						}, value))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "mt-4 block text-sm text-muted",
						htmlFor: "custom-minutes",
						children: "مدة مخصصة بالدقائق"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "custom-minutes",
						className: `${field} mt-2`,
						inputMode: "numeric",
						value: minutes,
						onChange: (event) => setMinutes(Math.min(720, Math.max(1, Number(event.target.value) || 1)))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: `${primary} mt-4 w-full`,
						disabled: now == null,
						onClick: beginManual,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-4" }),
							"اقفل الجهازين ",
							minutes < 60 ? `${minutes} د` : `${minutes / 60} س`
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-base font-medium",
						children: "جدول القفل"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "مثال: من الخامسة إلى السابعة. التفعيل ينسخ نفسه إلى الجهاز الآخر."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 flex flex-col gap-2",
						children: schedules.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-xl border border-line bg-bg p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: item.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm tabular-nums text-muted",
									children: [
										item.start,
										" – ",
										item.end,
										" · ",
										item.days.map((day) => WEEK.find((w) => w.d === day)?.label).join(" ")
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "text-sm text-muted",
									onClick: () => removeSchedule(item.id),
									children: "حذف"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: `mt-3 h-11 rounded-xl px-4 text-sm ${item.enabled ? "bg-sage text-bg" : "bg-surface-2 text-fg"}`,
								onClick: () => {
									if (!item.enabled && now != null && scheduleEnd({
										...item,
										enabled: true
									}, now) && armToggle !== item.id) {
										setArmToggle(item.id);
										notice("التفعيل سيغلق الجهازين الآن. اضغط مرة أخرى للتأكيد.");
										return;
									}
									toggleSchedule(item.id);
									setArmToggle(null);
								},
								children: item.enabled ? "مفعّل على الجهازين" : "غير مفعّل"
							})]
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-col gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-sm text-muted",
								htmlFor: "sch-label",
								children: "اسم الموعد"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "sch-label",
								className: field,
								value: label,
								onChange: (event) => setLabel(event.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-sm text-muted",
									children: ["من", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: `${field} mt-1`,
										type: "time",
										value: start,
										onChange: (event) => setStart(event.target.value)
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-sm text-muted",
									children: ["إلى", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: `${field} mt-1`,
										type: "time",
										value: end,
										onChange: (event) => setEnd(event.target.value)
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-2",
								children: WEEK.map((day) => {
									const on = days.includes(day.d);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: `h-11 rounded-xl px-3 text-sm ${on ? "bg-brass text-bg" : "bg-bg text-muted"}`,
										onClick: () => setDays((current) => current.includes(day.d) ? current.filter((d) => d !== day.d) : [...current, day.d]),
										children: day.label
									}, day.d);
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: primary,
								onClick: beginSchedule,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "إضافة الموعد"]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-base font-medium",
						children: "تعمل أثناء القفل"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "ما عدا هذه القائمة يُغطى بالقفل إذا فُتح بأي طريقة."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-col gap-2",
						children: [CATALOG.map((app) => {
							const on = allowed.some((item) => item.id === app.id);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "flex h-12 items-center justify-between rounded-xl bg-bg px-3 text-sm",
								onClick: () => toggleAllowed(app.id, app.name),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppIcon, { id: app.id }), app.name]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: on ? "text-sage" : "text-muted",
									children: on ? "مسموح" : "يُقفل"
								})]
							}, app.id);
						}), allowed.filter((app) => !CATALOG.some((item) => item.id === app.id)).map((app) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "flex h-12 items-center justify-between rounded-xl bg-bg px-3 text-sm",
							onClick: () => toggleAllowed(app.id, app.name),
							children: [app.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sage",
								children: "مسموح"
							})]
						}, app.id))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: field,
							placeholder: "اسم تطبيق آخر",
							value: customApp,
							onChange: (event) => setCustomApp(event.target.value),
							"aria-label": "تطبيق مسموح إضافي"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: ghost,
							onClick: () => {
								addCustomAllowed(customApp);
								setCustomApp("");
							},
							children: "إضافة"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-base font-medium",
						children: "خلفية القفل"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "لكل جهاز خلفية مستقلة، والعدّاد واحد."
					}),
					["phone", "laptop"].map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-sm",
							children: deviceName(id)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-4 gap-2",
							children: WALLPAPERS.map((wall) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: `wall wall-${wall.id} h-16 rounded-xl border text-xs ${wallpapers[id] === wall.id ? "border-brass" : "border-transparent"}`,
								onClick: () => commit((current) => ({
									wallpapers: {
										...current.wallpapers,
										[id]: wall.id
									},
									lastSync: current.transport === "bluetooth" ? "تحدّثت الخلفية · نُسخت عبر البلوتوث" : "تحدّثت الخلفية · نُسخت عبر الإنترنت"
								})),
								children: wall.name
							}, wall.id))
						})]
					}, id))
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-base font-medium",
						children: "نسخ الإعدادات"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "في هذه المعاينة ترى النسختين معاً، فأي قفل أو حد أو مهمة يصل إلى الجهاز الآخر فوراً. على الجهازين الحقيقيين تُرسل نفس الحالة عبر القناة التي تختارها."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: transport === "internet" ? primary : ghost,
							onClick: () => commit({
								transport: "internet",
								lastSync: "القناة: الإنترنت"
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cloud, { className: "size-4" }), " إنترنت"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: transport === "bluetooth" ? primary : ghost,
							onClick: () => commit({
								transport: "bluetooth",
								lastSync: "القناة: بلوتوث"
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bluetooth, { className: "size-4" }), " بلوتوث"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "mt-4 block text-sm text-muted",
						htmlFor: "pair",
						children: "رمز الربط"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "pair",
						className: `${field} mt-2 uppercase tracking-widest`,
						value: pairCode,
						maxLength: 8,
						onChange: (event) => commit({ pairCode: event.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8) })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-sage",
						children: lastSync
					})
				]
			})
		]
	});
}
function Limits({ now, onOpen }) {
	const limits = useFocus((s) => s.limits);
	const setLimitMinutes = useFocus((s) => s.setLimitMinutes);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-medium",
				children: "حد المقاطع القصيرة"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "عشر دقائق كل ساعة افتراضياً. الويب والتطبيق يحسبان من الرصيد نفسه. بعد النفاد يبقى البرنامج بلا مقاطع قصيرة."
			})] }),
			limits.map((rule) => {
				const cap = rule.minutesPerHour * 6e4;
				const pct = Math.min(100, Math.round(rule.usedMs / cap * 100));
				const left = Math.max(0, cap - rule.usedMs);
				const reset = now == null ? null : Math.ceil((Math.floor(now / 36e5 + 1) * 36e5 - now) / 1e3);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl border border-line bg-surface p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-medium",
								children: rule.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: rule.detail
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "tabular-nums text-sm text-brass",
								children: formatRemain(left)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 h-1.5 overflow-hidden rounded-full bg-bg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full bg-brass",
								style: { width: `${pct}%` }
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-muted",
							children: [
								Math.ceil(rule.usedMs / 6e4),
								" / ",
								rule.minutesPerHour,
								" د هذه الساعة",
								reset != null ? ` · تتجدد بعد ${formatRemain(reset * 1e3)}` : ""
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "mt-3 block text-sm text-muted",
							htmlFor: `lim-${rule.id}`,
							children: "الدقائق المسموحة كل ساعة"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: `lim-${rule.id}`,
							className: `${field} mt-1`,
							inputMode: "numeric",
							value: rule.minutesPerHour,
							onChange: (event) => setLimitMinutes(rule.id, Number(event.target.value) || 1)
						})
					]
				}, rule.id);
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: primary,
				onClick: () => onOpen("youtube"),
				children: "تجربة يوتيوب"
			})
		]
	});
}
function ShieldView({ now, notice }) {
	const strikes = useFocus((s) => s.tamperStrikes);
	const tamperNote = useFocus((s) => s.tamperNote);
	const [url, setUrl] = (0, import_react.useState)("");
	const [verdict, setVerdict] = (0, import_react.useState)(null);
	const drift = now == null ? 0 : clockDrift();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ban, { className: "size-5 text-brass" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-base font-medium",
							children: "حجب دائم"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "أي موقع إباحي أو هنتاي يُحجب في كل الأوقات على الهاتف والحاسوب، من المتصفح ومن التطبيقات. لا يوجد مفتاح إيقاف."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "mt-3 block text-sm text-muted",
						htmlFor: "adult-url",
						children: "جرّب عنواناً"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "adult-url",
							className: field,
							value: url,
							placeholder: "example.com",
							onChange: (event) => setUrl(event.target.value)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: ghost,
							onClick: () => setVerdict(isAdultTarget(url) ? "محجوب نهائياً" : "ليس ضمن الحجب الدائم"),
							children: "فحص"
						})]
					}),
					verdict ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-brass",
						children: verdict
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-5 text-brass" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-base font-medium",
							children: "التصفح الخفي متوقف"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "الزر موجود في مكانه حتى لا يُظن أنه اختفى، لكنه لا يفتح نافذة خاصة على أي جهاز."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IncognitoControl, { onBlock: () => notice("التصفح الخفي متوقف على الهاتف والحاسوب ولا يمكن فتحه.") })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-5 text-brass" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-base font-medium",
							children: "ساعة لا تُخدع"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "أثناء القفل يعتمد العدّاد ساعة داخلية. تقديم ساعة الجهاز أو تأخيرها لا ينهي القفل، ويُضاف خمس عشرة دقيقة. بعد إعادة التشغيل يُراجع الوقت مع الشبكة."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-3 grid grid-cols-2 gap-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl bg-bg p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "ساعة سكينة"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 tabular-nums",
								children: now == null ? "—" : clockFace(now)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl bg-bg p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "ساعة الجهاز"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 tabular-nums",
								children: now == null ? "—" : clockFace(Date.now() + drift)
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-sm",
						children: ["محاولات مكتشفة: ", strikes]
					}),
					tamperNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-brass",
						children: tamperNote
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: ghost,
								onClick: () => nudgeDemoClock(18e5),
								children: "محاكاة تقديم الساعة"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: ghost,
								onClick: () => nudgeDemoClock(-6e5),
								children: "محاكاة تأخير الساعة"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: ghost,
								onClick: () => {
									resetDemoClock();
									notice("عادت ساعة الجهاز الظاهرة إلى وضعها.");
								},
								children: "إرجاع الساعة الظاهرة"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: ghost,
								onClick: () => {
									const current = useFocus.getState();
									if (current.ready) savePersisted(toPersisted(current, trustedWall(), Date.now()));
									window.location.reload();
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "محاكاة إعادة التشغيل"]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "القفل هنا يغطي المعاينة بالكامل ويبقى بعد التحديث. النسخة المثبتة على ويندوز وأندرويد هي التي تجلس فوق النظام وتعطّل التصفح الخفي من إعدادات الجهاز."
			})
		]
	});
}
function IncognitoControl({ onBlock }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		"aria-disabled": "true",
		className: `${ghost} w-full opacity-60`,
		onClick: onBlock,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-4" }), "نافذة خاصة · متوقفة"]
	});
}
function PomoView({ now, notice, onPlay }) {
	const pomo = useFocus((s) => s.pomo);
	const startPomo = useFocus((s) => s.startPomo);
	const stopPomo = useFocus((s) => s.stopPomo);
	const setPomoCycles = useFocus((s) => s.setPomoCycles);
	const setSound = useFocus((s) => s.setSound);
	const totalMs = (pomo.phase === "break" ? 5 : 25) * 6e4;
	const left = pomo.phaseEndsAt != null && now != null ? Math.max(0, pomo.phaseEndsAt - now) : totalMs;
	const progress = totalMs === 0 ? 0 : left / totalMs;
	const radius = 52;
	const circ = 2 * Math.PI * radius;
	const phaseLabel = pomo.phase === "focus" ? "تركيز" : pomo.phase === "break" ? "استراحة" : "جاهز";
	function chooseFile(kind, file) {
		if (!file) return;
		setSoundClip(URL.createObjectURL(file));
		setSound(kind, file.name);
		notice(kind === "quran" ? "أُضيف ملف التلاوة على هذا الجهاز." : "أُضيف الصوت الخاص على هذا الجهاز.");
		if (useFocus.getState().pomo.phase !== "idle") onPlay();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative grid place-items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
					viewBox: "0 0 120 120",
					className: "size-56 text-brass",
					"aria-hidden": true,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "60",
						cy: "60",
						r: radius,
						fill: "none",
						stroke: "currentColor",
						strokeOpacity: .2,
						strokeWidth: "6"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "60",
						cy: "60",
						r: radius,
						fill: "none",
						stroke: "currentColor",
						strokeWidth: "6",
						strokeLinecap: "round",
						strokeDasharray: circ,
						strokeDashoffset: circ * (1 - progress),
						transform: "rotate(-90 60 60)"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-4xl font-light tabular-nums",
						children: formatRemain(left)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: phaseLabel
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"25 دقيقة تركيز ثم 5 استراحة · الدورة ",
					Math.min(pomo.cyclesDone + (pomo.phase === "idle" ? 0 : 1), pomo.cyclesPlanned),
					" من ",
					pomo.cyclesPlanned
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: ghost,
						disabled: pomo.phase !== "idle",
						onClick: () => setPomoCycles(pomo.cyclesPlanned - 1),
						children: "أقل"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular-nums",
						children: [pomo.cyclesPlanned, " دورات"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: ghost,
						disabled: pomo.phase !== "idle",
						onClick: () => setPomoCycles(pomo.cyclesPlanned + 1),
						children: "أكثر"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid w-full grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: pomo.sound === "rain" ? primary : ghost,
						onClick: () => {
							setSound("rain");
							if (pomo.phase !== "idle") onPlay();
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudRain, { className: "size-4" }), " مطر"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: pomo.sound === "quran" ? primary : ghost,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-4" }),
							" تلاوة",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "sr-only",
								type: "file",
								accept: "audio/*",
								onChange: (event) => chooseFile("quran", event.target.files?.[0] ?? null)
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: pomo.sound === "custom" ? primary : ghost,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Music, { className: "size-4" }),
							" خاص",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "sr-only",
								type: "file",
								accept: "audio/*",
								onChange: (event) => chooseFile("custom", event.target.files?.[0] ?? null)
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-sm text-muted",
				children: pomo.sound === "quran" ? pomo.customSoundName || "التلاوة ملف من جهازك، ولا تُولَّد تلاوة مصطنعة." : pomo.sound === "custom" ? pomo.customSoundName || "أضف ملف صوت من جهازك." : "صوت مطر خفيف أثناء الدورات."
			}),
			pomo.phase === "idle" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: `${primary} w-full`,
				disabled: now == null,
				onClick: () => {
					if (now == null) return;
					startPomo(now);
					onPlay();
				},
				children: [
					"ابدأ ",
					pomo.cyclesPlanned,
					" دورات"
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: `${ghost} w-full`,
				onClick: () => stopPomo(),
				children: "إيقاف السلسلة"
			})
		]
	});
}
function Agenda({ now }) {
	const tasks = useFocus((s) => s.tasks);
	const addTask = useFocus((s) => s.addTask);
	const toggleTask = useFocus((s) => s.toggleTask);
	const removeTask = useFocus((s) => s.removeTask);
	const today = now == null ? null : dayKeyFrom(now);
	const [picked, setPicked] = (0, import_react.useState)(null);
	const [title, setTitle] = (0, import_react.useState)("");
	const [time, setTime] = (0, import_react.useState)("17:00");
	const selected = picked ?? today ?? "*";
	const start = today ? weekStart(picked ?? today) : null;
	const visible = tasks.filter((task) => onThisDay(task, selected, today)).slice().sort((a, b) => a.minutes - b.minutes);
	const hours = Array.from({ length: 24 }, (_, hour) => hour);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: ghost,
						disabled: !today,
						onClick: () => setPicked(shiftDay(selected === "*" && today ? today : selected, -1)),
						children: "السابق"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-center text-base font-medium",
						children: selected === "*" || !today ? "اليوم" : dayTitle(selected)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: ghost,
						disabled: !today,
						onClick: () => setPicked(shiftDay(selected === "*" && today ? today : selected, 1)),
						children: "التالي"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-7 gap-1",
				children: WEEK.map((day, index) => {
					const key = start ? shiftDay(start, index) : "";
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: !start,
						className: `flex h-14 flex-col items-center justify-center rounded-xl text-xs ${key !== "" && key === (selected === "*" ? today : selected) ? "bg-brass text-bg" : "bg-surface text-muted"}`,
						onClick: () => key && setPicked(key),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: day.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: key ? key.slice(-2) : ""
						})]
					}, day.d);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-col gap-2 rounded-2xl border border-line bg-surface p-4",
				onSubmit: (event) => {
					event.preventDefault();
					if (!title.trim() || !today) return;
					const [h, m] = time.split(":").map(Number);
					addTask({
						title: title.trim(),
						day: selected === "*" ? today : selected,
						minutes: (h ?? 0) * 60 + (m ?? 0)
					});
					setTitle("");
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-sm text-muted",
						htmlFor: "task-title",
						children: "مهمة بالدقيقة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "task-title",
						className: field,
						value: title,
						onChange: (event) => setTitle(event.target.value),
						placeholder: "ماذا ستفعل"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: field,
						type: "time",
						value: time,
						onChange: (event) => setTime(event.target.value),
						"aria-label": "وقت المهمة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: primary,
						disabled: !today || !title.trim(),
						children: "إضافة إلى الجدول"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "max-h-[32rem] overflow-y-auto rounded-2xl border border-line",
				children: hours.map((hour) => {
					const rows = visible.filter((task) => Math.floor(task.minutes / 60) === hour);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-[4.5rem_minmax(0,1fr)] border-b border-line last:border-b-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "px-3 py-3 text-start text-sm tabular-nums text-muted",
							onClick: () => setTime(`${String(hour).padStart(2, "0")}:00`),
							children: formatMinutes(hour * 60)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-2 py-2 pe-3",
							children: [rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "py-2 text-sm text-muted",
								children: "—"
							}) : null, rows.map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: `grid size-11 place-items-center rounded-xl border ${task.done ? "border-sage bg-sage text-bg" : "border-line"}`,
										"aria-label": task.done ? `إلغاء إتمام ${task.title}` : `إتمام ${task.title}`,
										onClick: () => toggleTask(task.id),
										children: task.done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : null
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: task.done ? "text-muted line-through" : "",
											children: task.title
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm tabular-nums text-muted",
											children: formatMinutes(task.minutes)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "text-sm text-muted",
										onClick: () => removeTask(task.id),
										children: "حذف"
									})
								]
							}, task.id))]
						})]
					}, hour);
				})
			})
		]
	});
}
function dayTitle(key) {
	const [y, m, d] = key.split("-").map(Number);
	return new Date(y ?? 2026, (m ?? 1) - 1, d ?? 1).toLocaleDateString("ar", {
		weekday: "long",
		day: "numeric",
		month: "long"
	});
}
function LockScreen({ device, lock, now, onOpen, onSwitch, onPlay, notice }) {
	const wall = useFocus((s) => s.wallpapers[device]);
	const allowed = useFocus((s) => s.allowed);
	const pomo = useFocus((s) => s.pomo);
	const tamperNote = useFocus((s) => s.tamperNote);
	const startPomo = useFocus((s) => s.startPomo);
	const wallName = WALLPAPERS.find((item) => item.id === wall)?.name ?? "";
	const blocked = CATALOG.filter((app) => !allowed.some((item) => item.id === app.id));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `wall wall-${wall} fixed inset-0 z-40 flex items-center justify-center p-4`,
		role: "dialog",
		"aria-modal": "true",
		"aria-label": "الجهازان مقفلان",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md rounded-3xl bg-bg px-6 py-8 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						"الجهازان مقفلان · ",
						deviceName(device),
						" · خلفية ",
						wallName
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-6xl font-medium tabular-nums tracking-tight text-paper sm:text-7xl",
					children: formatRemain(lock.remainingMs)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-lg text-paper",
					children: lock.label
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						"ينتهي عند ",
						lock.endsAt ? clockFace(lock.endsAt).slice(0, 5) : "—",
						" · الساعة الداخلية ",
						clockFace(now)
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto my-6 h-px w-16 bg-brass" }),
				tamperNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-brass",
					children: tamperNote
				}) : null,
				pomo.phase !== "idle" && pomo.phaseEndsAt ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm tabular-nums text-paper",
					children: [
						"بومودورو ",
						pomo.phase === "focus" ? "تركيز" : "استراحة",
						" · ",
						formatRemain(pomo.phaseEndsAt - now)
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-3 text-sm text-brass underline decoration-from-font underline-offset-4",
					onClick: () => {
						startPomo(now);
						onPlay();
					},
					children: "بدء بومودورو 25 + 5"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 mt-8 text-sm text-muted",
					children: "مسموح فتحها الآن"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap justify-center gap-2",
					children: allowed.map((app) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-11 rounded-full border border-line bg-surface px-4 text-sm text-paper",
						onClick: () => onOpen(app.id),
						children: app.name
					}, app.id))
				}),
				blocked.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "mt-4 text-sm text-muted",
					onClick: () => {
						notice("هذه التطبيقات محجوبة طوال القفل، ولو فُتحت من مكان آخر تظهر سكينة فوقها.");
						onOpen(blocked[0]?.id ?? "games");
					},
					children: ["محجوب: ", blocked.map((app) => app.name).slice(0, 4).join("، ")]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "mt-3 text-sm text-brass",
					onClick: onSwitch,
					children: ["خلفية ", deviceName(device === "phone" ? "laptop" : "phone")]
				})
			]
		})
	});
}
function AppLayer({ id, locked, remaining, now, playing, onPlay, onClose, notice }) {
	const name = useFocus((s) => s.allowed).find((app) => app.id === id)?.name ?? CATALOG.find((app) => app.id === id)?.name ?? "تطبيق";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-40 flex flex-col bg-bg text-fg",
		children: [locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-3 border-b border-line bg-surface px-4 py-2 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "tabular-nums",
				children: ["متبقٍ على القفل ", formatRemain(remaining)]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "h-11 px-2",
				onClick: onClose,
				children: "العودة إلى القفل"
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between border-b border-line px-4 py-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-medium",
				children: name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "h-11 px-2 text-sm",
				onClick: onClose,
				children: "إغلاق"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-h-0 flex-1 overflow-y-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeviceApp, {
				id,
				name,
				now,
				playing,
				onPlay,
				notice
			})
		})]
	});
}
function DeviceApp({ id, name, now, playing, onPlay, notice }) {
	if (id === "youtube") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoApp, {
		limitId: "shorts",
		title: "يوتيوب",
		longLabel: "الرئيسية",
		shortLabel: "شورتس",
		now,
		playing,
		onPlay
	});
	if (id === "instagram") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoApp, {
		limitId: "reels",
		title: "إنستغرام",
		longLabel: "المنشورات",
		shortLabel: "ريلز",
		now,
		playing,
		onPlay
	});
	if (id === "tiktok") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoApp, {
		limitId: "tiktok",
		title: "تيك توك",
		longLabel: "حسابات بلا تشغيل",
		shortLabel: "المقاطع",
		now,
		playing,
		onPlay,
		defaultShort: true
	});
	if (id === "browser") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrowserPane, {
		now,
		playing,
		onPlay,
		notice
	});
	if (id === "call") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CallPane, {});
	if (id === "sms") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SmsPane, {});
	if (id === "maps") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPane, {});
	if (id === "notes") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotesPane, {});
	if (id === "games") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "text-lg font-medium",
			children: "الألعاب"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: "متاحة ما دام الجهاز مفتوحاً. أثناء القفل لا تُفتح إلا إذا أضفتها إلى المسموح."
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "text-lg font-medium",
			children: name
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: "تطبيق مسموح أثناء القفل. لا يُحسب من وقت المقاطع القصيرة."
		})]
	});
}
function VideoApp({ limitId, title, longLabel, shortLabel, now, playing, onPlay, defaultShort, initialSurface = "app" }) {
	const [surface, setSurface] = (0, import_react.useState)(initialSurface);
	const [mode, setMode] = (0, import_react.useState)(defaultShort ? "short" : "long");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4 p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-lg font-medium",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex rounded-xl border border-line p-1 text-sm",
					children: ["app", "web"].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: `h-9 rounded-lg px-3 ${surface === item ? "bg-brass text-bg" : "text-muted"}`,
						onClick: () => setSurface(item),
						children: item === "app" ? "التطبيق" : "الويب"
					}, item))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: mode === "long" ? primary : ghost,
					onClick: () => {
						setMode("long");
						onPlay(null);
					},
					children: longLabel
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: mode === "short" ? primary : ghost,
					onClick: () => setMode("short"),
					children: shortLabel
				})]
			}),
			mode === "long" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: [
					"شرح طويل · 42 د",
					"محاضرة · 28 د",
					"مقابلة · 16 د"
				].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-xl border border-line bg-surface px-4 py-3 text-sm",
					children: [item, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted",
						children: "لا يُحسب من حد المقاطع القصيرة"
					})]
				}, item))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShortStage, {
				id: limitId,
				surface,
				now,
				playing: playing === limitId,
				onPlay
			})
		]
	});
}
function ShortStage({ id, surface, now, playing, onPlay }) {
	const rule = useFocus((s) => s.limits.find((item) => item.id === id));
	const consumeLimit = useFocus((s) => s.consumeLimit);
	if (!rule) return null;
	const cap = rule.minutesPerHour * 6e4;
	const exhausted = rule.usedMs >= cap;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-line bg-surface p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-sm text-muted",
			children: [
				surface === "web" ? "نسخة الويب" : "نسخة التطبيق",
				" · الرصيد مشترك · متبقٍ ",
				formatRemain(Math.max(0, cap - rule.usedMs))
			]
		}), exhausted ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 flex flex-col items-start gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-medium",
				children: "المقاطع القصيرة متوقفة حتى الساعة التالية."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "يمكنك البقاء في البرنامج وقراءة المحتوى الطويل. تشغيل أي مقطع، من الويب أو التطبيق، يبقى مغلقاً."
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 flex flex-col gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `grid h-48 place-items-center rounded-xl ${playing ? "bg-brass text-bg" : "bg-bg"}`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: playing ? "المقطع يعمل ويُحتسب من الساعة" : "المقطع متوقف"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: primary,
					onClick: () => onPlay(playing ? null : id),
					children: playing ? "إيقاف" : "تشغيل"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: ghost,
					onClick: () => {
						if (now == null) return;
						consumeLimit(id, 6e4, now);
					},
					children: "احتساب دقيقة"
				})]
			})]
		})]
	});
}
function BrowserPane({ now, playing, onPlay, notice }) {
	const [url, setUrl] = (0, import_react.useState)("");
	const [target, setTarget] = (0, import_react.useState)("");
	const adult = target ? isAdultTarget(target) : false;
	const host = target.toLowerCase();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-full flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2 border-b border-line p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: field,
					value: url,
					placeholder: "ابحث أو أدخل موقعاً",
					"aria-label": "شريط العنوان",
					onChange: (event) => setUrl(event.target.value),
					onKeyDown: (event) => {
						if (event.key === "Enter") setTarget(url);
					}
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: ghost,
					onClick: () => setTarget(url),
					children: "فتح"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-3 pt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IncognitoControl, { onBlock: () => notice("التصفح الخفي متوقف على هذا الجهاز ولا يُفتح من الويب ولا من التطبيق.") })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 p-4",
				children: [
					!target ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "المتصفح العادي يعمل. النافذة الخاصة لا تعمل."
					}) : null,
					target && adult ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col items-center gap-3 py-16 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ban, { className: "size-8 text-brass" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-xl font-medium",
								children: "محجوب نهائياً"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "max-w-sm text-sm text-muted",
								children: "هذا العنوان ضمن المحتوى الإباحي أو الهنتاي. الحجب دائم ولا يُتجاوز من التصفح الخفي لأنه متوقف أصلاً."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: ghost,
								onClick: () => {
									setTarget("");
									setUrl("");
								},
								children: "رجوع"
							})
						]
					}) : null,
					target && !adult && /youtube|youtu\.be/.test(host) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoApp, {
						limitId: "shorts",
						title: "يوتيوب على الويب",
						longLabel: "فيديوهات طويلة",
						shortLabel: "شورتس",
						now,
						playing,
						onPlay,
						initialSurface: "web"
					}) : null,
					target && !adult && /instagram/.test(host) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoApp, {
						limitId: "reels",
						title: "إنستغرام على الويب",
						longLabel: "المنشورات",
						shortLabel: "ريلز",
						now,
						playing,
						onPlay,
						initialSurface: "web"
					}) : null,
					target && !adult && /tiktok/.test(host) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoApp, {
						limitId: "tiktok",
						title: "تيك توك على الويب",
						longLabel: "بدون تشغيل",
						shortLabel: "المقاطع",
						now,
						playing,
						onPlay,
						initialSurface: "web",
						defaultShort: true
					}) : null,
					target && !adult && !/youtube|youtu\.be|instagram|tiktok/.test(host) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-2xl border border-line bg-surface p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-medium",
							children: "صفحة عادية"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: "هذا العنوان ليس ضمن الحجب الدائم ويمكن فتحه خارج وقت قفل الجهاز."
						})]
					}) : null
				]
			})
		]
	});
}
function CallPane() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "flex flex-col gap-2 p-4",
		children: [
			"أحمد",
			"ليلى",
			"المنزل"
		].map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex items-center justify-between rounded-2xl border border-line bg-surface px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "inline-flex items-center gap-2 text-sm text-sage",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4" }), " اتصال"]
			})]
		}, name))
	});
}
function SmsPane() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3 p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "max-w-xs rounded-2xl bg-surface px-4 py-3 text-sm",
			children: "وصلت؟"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "ms-auto max-w-xs rounded-2xl bg-brass px-4 py-3 text-sm text-bg",
			children: "أنا في التركيز حتى نهاية العدّاد."
		})]
	});
}
function MapPane() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative grid h-80 place-items-center overflow-hidden rounded-2xl border border-line bg-surface-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-0 top-16 h-px bg-line" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-0 top-40 h-px bg-line" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-y-0 start-16 w-px bg-line" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-y-0 start-40 w-px bg-line" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "relative size-4 rounded-full bg-brass" })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm text-muted",
			children: "أنت هنا. الاتجاهات الأساسية تبقى متاحة أثناء القفل."
		})]
	});
}
function NotesPane() {
	const notes = useFocus((s) => s.notes);
	const setNotes = useFocus((s) => s.setNotes);
	const [draft, setDraft] = (0, import_react.useState)(notes);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			className: "min-h-64 w-full rounded-2xl border border-line bg-surface p-4 text-sm outline-none focus-visible:border-brass",
			value: draft,
			onChange: (event) => setDraft(event.target.value),
			onBlur: () => setNotes(draft),
			"aria-label": "ملاحظة"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: "تُحفظ الملاحظة عند مغادرة الحقل وتُنسخ إلى الجهاز الآخر."
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sakeena, {});
}
//#endregion
export { Home as component };
