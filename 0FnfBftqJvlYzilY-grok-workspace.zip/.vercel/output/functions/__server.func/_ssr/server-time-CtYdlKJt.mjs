import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/server-time-CtYdlKJt.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getServerNow_createServerFn_handler = createServerRpc({
	id: "00e823cecaae52c5c83ff22b3f1139116ce0152d73327ada89bbdf9363fdb4d0",
	name: "getServerNow",
	filename: "src/lib/focus/server-time.ts"
}, (opts) => getServerNow.__executeServer(opts));
var getServerNow = createServerFn({ method: "GET" }).handler(getServerNow_createServerFn_handler, async () => {
	return { now: Date.now() };
});
//#endregion
export { getServerNow_createServerFn_handler };
